-- MySQL dump 10.13  Distrib 5.5.50, for Linux (x86_64)
--
-- Host: localhost    Database: chilectr_app
-- ------------------------------------------------------
-- Server version	5.5.50-cll

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `adjuntos`
--

DROP TABLE IF EXISTS `adjuntos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `adjuntos` (
  `adjunto_id` int(12) NOT NULL AUTO_INCREMENT,
  `adjunto_titulo` varchar(255) DEFAULT NULL,
  `adjunto_archivo` varchar(255) DEFAULT NULL,
  `usuario_id` int(12) DEFAULT NULL,
  `proceso_id` int(12) NOT NULL,
  `proyecto_id` int(12) NOT NULL,
  `etapa_id` int(12) DEFAULT NULL,
  `tarea_id` int(12) DEFAULT NULL,
  PRIMARY KEY (`adjunto_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `adjuntos`
--

LOCK TABLES `adjuntos` WRITE;
/*!40000 ALTER TABLE `adjuntos` DISABLE KEYS */;
INSERT INTO `adjuntos` (`adjunto_id`, `adjunto_titulo`, `adjunto_archivo`, `usuario_id`, `proceso_id`, `proyecto_id`, `etapa_id`, `tarea_id`) VALUES (1,'ffsfsdfsdfs','Koala.jpg',1,30,14,3,14),(2,'kklkl','Koala1.jpg',1,36,18,3,14),(3,'test','test.png',1,30,14,3,14),(4,'foto proyecto','FullSizeRender_(2).jpg',5,41,19,3,14),(5,'adjunto archivo','Vitacura.jpg',4,44,20,3,14),(6,'foto','FullSizeRender_(2)1.jpg',5,45,20,3,14),(7,'otra foto','FullSizeRender.jpg',5,46,20,3,14),(8,'hola','Hola_mundo1.pdf',1,73,24,3,14);
/*!40000 ALTER TABLE `adjuntos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bitacoras`
--

DROP TABLE IF EXISTS `bitacoras`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bitacoras` (
  `bitacora_id` int(12) NOT NULL AUTO_INCREMENT,
  `tarea_id` int(12) DEFAULT NULL,
  `etapa_id` int(12) DEFAULT NULL,
  `bitacora_registro` mediumtext,
  `usuario_id` int(12) DEFAULT NULL,
  `proceso_id` int(12) NOT NULL,
  `proyecto_id` int(12) NOT NULL,
  PRIMARY KEY (`bitacora_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bitacoras`
--

LOCK TABLES `bitacoras` WRITE;
/*!40000 ALTER TABLE `bitacoras` DISABLE KEYS */;
/*!40000 ALTER TABLE `bitacoras` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `etapas`
--

DROP TABLE IF EXISTS `etapas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `etapas` (
  `etapa_id` int(12) NOT NULL AUTO_INCREMENT,
  `etapa_nombre` varchar(120) DEFAULT NULL,
  `etapa_requerido` mediumtext,
  `etapa_orden` int(2) NOT NULL,
  PRIMARY KEY (`etapa_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `etapas`
--

LOCK TABLES `etapas` WRITE;
/*!40000 ALTER TABLE `etapas` DISABLE KEYS */;
INSERT INTO `etapas` (`etapa_id`, `etapa_nombre`, `etapa_requerido`, `etapa_orden`) VALUES (3,'PROPUESTA COMERCIAL','',1),(5,'NEGOCIACIÓN Y ADJUDICACIÓN','',2),(6,'EJECUCIÓN','',3),(7,'RECEPCIÓN PROVISORIA','',4),(8,'GARANTÍA','',5),(9,'RECEPCIÓN DEFINITIVA','',6);
/*!40000 ALTER TABLE `etapas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `etapas_campos`
--

DROP TABLE IF EXISTS `etapas_campos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `etapas_campos` (
  `etapa_campo_id` int(11) NOT NULL AUTO_INCREMENT,
  `etapa_v2_id` int(11) NOT NULL,
  `etapa_campo_nombre` varchar(60) NOT NULL,
  `etapa_campo_tipo` varchar(60) NOT NULL,
  `etapa_campo_descripcion` varchar(60) NOT NULL,
  PRIMARY KEY (`etapa_campo_id`)
) ENGINE=InnoDB AUTO_INCREMENT=155 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `etapas_campos`
--

LOCK TABLES `etapas_campos` WRITE;
/*!40000 ALTER TABLE `etapas_campos` DISABLE KEYS */;
INSERT INTO `etapas_campos` (`etapa_campo_id`, `etapa_v2_id`, `etapa_campo_nombre`, `etapa_campo_tipo`, `etapa_campo_descripcion`) VALUES (1,1,'nombre_del_proyecto','text','Nombre del Proyecto'),(2,1,'cliente','text','Cliente'),(3,1,'tipo_proyecto','text','Tipo de Proyecto'),(4,1,'linea_de_negocio','text','Linea de Negocio'),(5,1,'adjuntar_archivo','file','Adjuntar Archivo'),(6,1,'direccion','text','Dirección'),(7,1,'telefono','text','Teléfono'),(8,1,'email','text','E-Mail'),(9,1,'rut','text','RUT'),(10,1,'bitacora','textarea','Bitácora'),(11,1,'fecha_de_inicio','date','Fecha de Inicio Etapa 1'),(12,2,'fecha_de_inicio','date','Fecha de Inicio Etapa 2'),(13,2,'adjuntar_archivo','file','Adjuntar Archivo'),(14,2,'seleccionar_contratista ','select','Lista Desplegable Para Seleccionar Contratista'),(15,2,'plazo_de_desarrollo_de_propuesta','select','Lista Desplegable de Plazo de Desarrollo de Propuesta'),(16,2,'rechazar','button','Botón Rechazar'),(17,2,'bitacora','textarea','Bitácora'),(18,3,'fecha_de_inicio','date','Fecha de Inicio Etapa 3'),(19,3,'adjuntar_archivo','file','Adjuntar Archivo'),(20,3,'itemizado_generico_nombre1','text','Itemizado Genérico Nombre (máximo 10 items)'),(21,3,'itemizado_generico_costo','textarea','Itemizado Genérico Costo'),(22,3,'plazo_costruccion','select','Plazo Cosntrucción'),(23,3,'garantia_equipos','text','Garantía Equipos'),(24,3,'garantia_instalacion','text','Garantía Instalación'),(25,3,'bitacora','textarea','Bitácora'),(26,3,'rechazar','button','Botón Rechazar'),(27,4,'fecha_de_inicio','date','Fecha de Inicio Etapa 4'),(28,4,'adjuntar_archivo','file','Adjuntar Archivo'),(29,4,'margen','text','Margen (%)'),(30,4,'bitacora','textarea','Bitácora'),(31,4,'rechazar','button','Botón Rechazar'),(32,5,'fecha_de_inicio','date','Fecha de Inicio Etapa 5'),(33,5,'adjuntar_archivo','file','Adjuntar Archivo'),(34,5,'margen','text','Margen Propuesto (%)'),(35,5,'bitacora','textarea','Bitácora'),(36,5,'boton_rechazar','button','Botón Rechazar'),(37,6,'fecha_de_inicio','date','Fecha de Inicio Etapa 6'),(38,6,'adjuntar_archivo','file','Adjuntar Archivo'),(39,6,'bitacora','textarea','Bitácora'),(40,6,'terminar_proyecto','button','Botón Terminar Proyecto (En caso de perder negocio)'),(41,7,'fecha_de_inicio','date','Fecha de Inicio Etapa 7'),(42,7,'adjuntar_archivo','file','Adjuntar Archivo'),(43,7,'margen_cierre','text','Margen Cierre (%)'),(44,7,'bitacora','textarea','Bitácora'),(45,7,'check_orden_de_compra','checkbox','Check Orden de Compra'),(46,8,'fecha_de_inicio','date','Fecha de Inicio Etapa 8'),(47,8,'adjuntar_archivo','file','Adjuntar Archivo'),(48,8,'fecha_de_acta_de_entrega','date','Fecha de Acta de Entrega'),(49,8,'bitacora','textarea','Bitácora'),(50,8,'check_se_adjunta_entrega_de_terreno','checkbox','Cuadro Check Se Adjunta Entrega de Terreno'),(51,8,'check_boleta_garantia_ejecucion_contratista','checkbox','Cuadro Check Boleta Garantía Ejecución Contratista'),(52,9,'adjunto_archivo','file','Adjuntar Archivo'),(53,9,'ingreso_de_plazo_en_dias','text','Ingreso de Plazo (días)'),(54,9,'bitacora','textarea','Bitácora'),(55,9,'email_adquisicion','checkbox','E-mail Adquisición'),(56,10,'adjunto_archivo','file','Adjuntar Archivo'),(57,10,'ingreso_de_plazo_en_dias','text','Ingreso de plazo (Días)'),(58,10,'bitacora','textarea','Bitácora'),(59,10,'ingenieria_de_detalle_aprobada','checkbox','Ingeniería de Detalle Aprobada'),(60,10,'memoria_de_calculo','checkbox','Memoria de Cálculo'),(61,10,'aprobacion_emplazamiento','checkbox','Aprobación Emplazamiento'),(62,11,'adjunto_archivo','file','Adjuntar Archivo'),(63,11,'ingreso_de_plazo_en_dias','text','Ingreso de plazo (Días)'),(64,11,'bitacora','textarea','Bitácora'),(65,11,'registro_fotografico','checkbox','Registro Fotográfico'),(66,11,'ipal','checkbox','IPAL'),(67,12,'adjunto_archivo','file','Adjuntar Archivo'),(68,12,'ingreso_de_plazo_en_dias','text','Ingreso de Plazo(Días)'),(69,12,'bitacora','textarea','Bitácora'),(70,12,'itemizado_generico1','date','Itemizado Genérico Fecha de inicio 1'),(71,12,'registro_fotografico','checkbox','Registro Fotográfico'),(72,12,'ipal','checkbox','IPAL'),(73,13,'adjunto_archivo','file','Adjuntar Archivo'),(74,13,'anexo_SEC','checkbox','Anexo SEC'),(75,13,'pruebas_operaciones','checkbox','Pruebas Operacionales'),(76,13,'registro_fotografico','checkbox','Registro Fotográfico'),(77,13,'fecha_de_puesta_en_marcha','date','Fecha de Puesta en Marcha'),(78,14,'adjunto_archivo','file','Adjuntar Archivo'),(79,14,'plazo_de_correcciones_de_observaciones','date','Plazo de Corrección de Observaciones'),(80,14,'observaciones','checkbox','observaciones'),(81,14,'observaciones_corregidas','checkbox','Observaciones Corregidas'),(82,15,'adjuntar_archivo','file','Adjuntar Archivo'),(83,15,'recepcion_provisoria','checkbox','Recepción Provisoria'),(84,15,'plazo_de_correcciones_de_observaciones','date','Fecha de Recepción Provisoria'),(85,16,'adjuntar_archivo','file','Adjuntar Archivo'),(86,16,'itemizado_generico1','date','Itemizado Genérico Fecha de inicio de garantía 1'),(87,16,'boleta_periodo_garantia_contratista','checkbox','Boleta Periodo Garantía Contratista'),(88,17,'adjuntar_archivo','acta_de_capacitacion',''),(89,17,'acta_de_capacitacion','checkbox','Acta de Capacitación'),(90,17,'fecha_de_capacitacion','date','Fecha de Capacitación'),(91,18,'adjuntar_archivo','file','Adjuntar Archivo'),(92,18,'entrega_manuales_equipos','checkbox','Entrega Manuales Equipos'),(93,18,'acta_de_garantia_y_postventa','checkbox','Acta de Garantía y Postventa'),(94,19,'adjuntar_archivo','file','Adjuntar Archivo'),(95,19,'bitacora','textarea','Bitácora'),(96,19,'archivos_fotograficos','checkbox','Archivos fotográficos'),(97,12,'itemizado_generico2','date','Itemizado Genérico Fecha de inicio 2'),(98,12,'itemizado_generico3','date','Itemizado Genérico Fecha de inicio 3'),(99,12,'itemizado_generico4','date','Itemizado Genérico Fecha de inicio 4'),(100,12,'itemizado_generico5','date','Itemizado Genérico Fecha de inicio 5'),(101,12,'itemizado_generico6','date','Itemizado Genérico Fecha de inicio 6'),(102,12,'itemizado_generico7','date','Itemizado Genérico Fecha de inicio 7'),(103,12,'itemizado_generico8','date','Itemizado Genérico Fecha de inicio 8'),(104,12,'itemizado_generico9','date','Itemizado Genérico Fecha de inicio 9'),(105,12,'itemizado_generico10','date','Itemizado Genérico Fecha de inicio 10'),(106,12,'itemizado_generico11','date','Itemizado Genérico Fecha de término 1'),(107,12,'itemizado_generico12','date','Itemizado Genérico Fecha de término 2'),(108,12,'itemizado_generico13','date','Itemizado Genérico Fecha de término 3'),(109,12,'itemizado_generico14','date','Itemizado Genérico Fecha de término 4'),(110,12,'itemizado_generico15','date','Itemizado Genérico Fecha de término 5'),(111,12,'itemizado_generico16','date','Itemizado Genérico Fecha de término 6'),(112,12,'itemizado_generico17','date','Itemizado Genérico Fecha de término 7'),(113,12,'itemizado_generico18','date','Itemizado Genérico Fecha de término 8'),(114,12,'itemizado_generico19','date','Itemizado Genérico Fecha de término 9'),(115,12,'itemizado_generico20','date','Itemizado Genérico Fecha de término 10'),(116,16,'itemizado_generico2','date','Itemizado Genérico Fecha de inicio de garantía 2'),(117,16,'itemizado_generico3','date','Itemizado Genérico Fecha de inicio de garantía 3'),(118,16,'itemizado_generico4','date','Itemizado Genérico Fecha de inicio de garantía 4'),(119,16,'itemizado_generico5','date','Itemizado Genérico Fecha de inicio de garantía 5'),(120,16,'itemizado_generico6','date','Itemizado Genérico Fecha de inicio de garantía 6'),(121,16,'itemizado_generico7','date','Itemizado Genérico Fecha de inicio de garantía 7'),(122,16,'itemizado_generico8','date','Itemizado Genérico Fecha de inicio de garantía 8'),(123,16,'itemizado_generico9','date','Itemizado Genérico Fecha de inicio de garantía 9'),(124,16,'itemizado_generico10','date','Itemizado Genérico Fecha de inicio de garantía 10'),(125,20,'cuadro_check_acta_recepcion_definitiva','checkbox','Cuadro Check Acta Recepción Definitiva'),(126,3,'itemizado_generico_nombre2','text','Itemizado Genérico Nombre 2'),(127,3,'itemizado_generico_nombre3','text','Itemizado Genérico Nombre 3'),(128,3,'itemizado_generico_nombre4','text','Itemizado Genérico Nombre 4'),(129,3,'itemizado_generico_nombre5','text','Itemizado Genérico Nombre 5'),(130,3,'itemizado_generico_nombre6','text','Itemizado Genérico Nombre 6'),(131,3,'itemizado_generico_nombre7','text','Itemizado Genérico Nombre 7'),(132,3,'itemizado_generico_nombre8','text','Itemizado Genérico Nombre 8'),(133,3,'itemizado_generico_nombre9','text','Itemizado Genérico Nombre 9'),(134,3,'itemizado_generico_nombre10','text','Itemizado Genérico Nombre 10'),(135,12,'itemizado_generico_nombre1','text','Itemizado Genérico nombre 1'),(136,12,'itemizado_generico_nombre2','text','Itemizado Genérico Nombre 2'),(137,12,'itemizado_generico_nombre3','text','Itemizado Genérico Nombre 3'),(138,12,'itemizado_generico_nombre4','text','Itemizado Genérico Nombre 4'),(139,12,'itemizado_generico_nombre5','text','Itemizado Genérico Nombre 5'),(140,12,'itemizado_generico_nombre6','text','Itemizado Genérico Nombre 6'),(141,12,'itemizado_generico_nombre7','text','Itemizado Genérico Nombre 7'),(142,12,'itemizado_generico_nombre8','text','Itemizado Genérico Nombre 8'),(143,12,'itemizado_generico_nombre9','text','Itemizado Genérico Nombre 9'),(144,12,'itemizado_generico_nombre10','text','Itemizado Genérico Nombre 10'),(145,16,'itemizado_generico_nombre1','text','Itemizado Genérico nombre 1'),(146,16,'itemizado_generico_nombre2','text','Itemizado Genérico nombre 2'),(147,16,'itemizado_generico_nombre3','text','Itemizado Genérico nombre 3'),(148,16,'itemizado_generico_nombre4','text','Itemizado Genérico nombre 4'),(149,16,'itemizado_generico_nombre5','text','Itemizado Genérico nombre 5'),(150,16,'itemizado_generico_nombre6','text','Itemizado Genérico nombre 6'),(151,16,'itemizado_generico_nombre7','text','Itemizado Genérico nombre 7'),(152,16,'itemizado_generico_nombre8','text','Itemizado Genérico nombre 8'),(153,16,'itemizado_generico_nombre9','text','Itemizado Genérico nombre 9'),(154,16,'itemizado_generico_nombre10','text','Itemizado Genérico nombre 10');
/*!40000 ALTER TABLE `etapas_campos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `etapas_v2`
--

DROP TABLE IF EXISTS `etapas_v2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `etapas_v2` (
  `etapa_v2_id` int(11) NOT NULL AUTO_INCREMENT,
  `etapa_v2_nombre` varchar(60) NOT NULL,
  `etapa_v2_url` varchar(66) NOT NULL,
  `etapa_v2_responsable` varchar(90) NOT NULL,
  PRIMARY KEY (`etapa_v2_id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `etapas_v2`
--

LOCK TABLES `etapas_v2` WRITE;
/*!40000 ALTER TABLE `etapas_v2` DISABLE KEYS */;
INSERT INTO `etapas_v2` (`etapa_v2_id`, `etapa_v2_nombre`, `etapa_v2_url`, `etapa_v2_responsable`) VALUES (1,'Ingreso Proyecto','ingreso_proyecto','EN'),(2,'Envio Solicitud a Contratista','envio_solicitud_a_contratista','ES'),(3,'Desarrollo de Propuesta','desarrollo_de_propuesta','EN'),(4,'Revisión de Propuesta','revision_de_propuesta','ES'),(5,'Envio Propuesta Cliente','envio_propuesta_cliente','EN'),(6,'Etapa de Negociación','etapa_de_negociacion','EN'),(7,'Adjudicación','adjudicacion','EN'),(8,'Entrega de Terreno','entrega_de_terreno','ES'),(9,'Adquisición de Equipos y Productos','adquisicion_de_equipos_y_productos','ES'),(10,'Ingeniería de Detalle','ingenieria_de_detalle','ES'),(11,'Obras Civiles u Otras','obras_civiles_u_otras','ES'),(12,'Instalación de Equipos','instalacion_de_equipos','ES'),(13,'Puesta en Marcha del Sistema','puesta_en_marcha_del_sistema','ES'),(14,'Corrección de Observaciones','correccion_de_observaciones','ES'),(15,'Recepción Provisoria','recepcion_provisoria','ES'),(16,'Inicio de la Etapa de Garantía','inicio_de_la_etapa_de_garantia','ES'),(17,'Capacitación','capacitacion','ES'),(18,'Entrega de Manuales e Información Postventa y Garantía','entrega_de_manuales_e_informacion_de_postventa_y_garantia','ES'),(19,'Atención Postventa','atencion_postventa','ES'),(20,'Recepción Definitiva','recepcion_definitiva','ES');
/*!40000 ALTER TABLE `etapas_v2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `etapas_v2_campos`
--

DROP TABLE IF EXISTS `etapas_v2_campos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `etapas_v2_campos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `etapa_v2_id` int(11) NOT NULL,
  `proyecto_id` int(11) NOT NULL,
  `usuario_id` int(11) NOT NULL,
  `etapa_campo_id` int(11) NOT NULL,
  `etapa_v2_campo_contenido` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1828 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `etapas_v2_campos`
--

LOCK TABLES `etapas_v2_campos` WRITE;
/*!40000 ALTER TABLE `etapas_v2_campos` DISABLE KEYS */;
INSERT INTO `etapas_v2_campos` (`id`, `etapa_v2_id`, `proyecto_id`, `usuario_id`, `etapa_campo_id`, `etapa_v2_campo_contenido`) VALUES (1,1,21,1,1,'Imacon'),(2,1,21,1,2,'Esteban burgos'),(3,1,21,1,3,'Sitio web'),(4,1,21,1,4,'Plataforma web'),(5,1,21,1,5,'Hola mundo.pdf'),(6,1,21,1,6,'Al lado de la Municipalidad de Padre Hurtado'),(7,1,21,1,7,'77665730'),(8,1,21,1,8,'esteban.n.burgos@gmail.com'),(9,1,21,1,9,'11.111.111-k'),(10,1,21,1,10,'Escribir algo aquí1'),(11,1,33,1,1,'Imacon1'),(12,1,33,1,2,'Esteban burgos1'),(13,1,33,1,3,'Sitio web1'),(14,1,33,1,4,'Plataforma web1'),(15,1,33,1,5,'Lighthouse11.jpg'),(16,1,33,1,6,'Al lado de la Municipalidad de Padre Hurtado1'),(17,1,33,1,7,'11223344'),(18,1,33,1,8,'esteban.imacom@gmail.com'),(19,1,33,1,9,'11.111.111-1'),(20,1,33,1,10,'1234555'),(21,2,33,1,12,'09/07/2015'),(22,2,33,1,13,'Lighthouse11.jpg'),(23,2,33,1,14,'3'),(24,2,33,1,15,'15 Días'),(25,2,33,1,17,'546754'),(26,2,33,1,16,'rechazar'),(29,3,33,1,18,'05/07/2015'),(30,3,33,1,19,'Penguins11.jpg'),(31,3,33,1,20,'Itemizado Genérico nombre'),(32,3,33,1,21,'Itemizado Genérico Costo'),(33,3,33,1,22,'15 Días'),(34,3,33,1,23,'Garantía de Equipo'),(35,3,33,1,24,'Garantía de Instalación'),(36,3,33,1,25,'Bitácora etapa 3'),(37,3,33,1,26,'rechazar'),(38,4,33,1,27,'11/08/2015'),(39,4,33,1,28,'Penguins11.jpg'),(40,4,33,1,29,'0.18'),(41,4,33,1,30,'Bitácora etapa 4'),(42,4,33,1,31,'rechazar'),(43,5,33,1,32,'12/08/2015'),(44,5,33,1,33,'Penguins11.jpg'),(45,5,33,1,34,'1.75'),(46,5,33,1,35,'Bitácora etapa 5'),(47,5,33,1,36,'rechazar'),(48,6,33,1,37,'17/08/2015'),(49,6,33,1,38,'Penguins11.jpg'),(50,6,33,1,39,'Bitácora Etapa 6'),(51,6,33,1,40,'terminar_proyecto'),(52,7,33,1,41,'19/08/2015'),(53,7,33,1,42,'Desert.jpg'),(54,7,33,1,43,'2'),(55,7,33,1,44,'Bitácora etapa 7'),(56,7,33,1,45,'1'),(57,8,33,1,46,'08/20/2015'),(58,8,33,1,47,'Jellyfish.jpg'),(59,8,33,1,48,'08/23/2015'),(60,8,33,1,49,'Bitácora etapa 8'),(61,8,33,1,50,'1'),(62,8,33,1,51,'1'),(63,9,33,1,52,'Penguins11.jpg'),(64,9,33,1,53,'4'),(65,9,33,1,54,'Bitácora etapa 9'),(66,9,33,1,55,'2,3'),(67,10,33,1,56,'Penguins11.jpg'),(68,10,33,1,57,'5'),(69,10,33,1,58,'Bitácora etapa 10'),(70,10,33,1,59,'2'),(71,10,33,1,60,'2'),(72,10,33,1,61,'1'),(73,11,33,1,62,'Chrysanthemum.jpg'),(74,11,33,1,63,'3'),(75,11,33,1,64,'Bitácora etapa 11'),(76,11,33,1,65,'1,2,3'),(77,11,33,1,66,'1'),(109,12,33,1,67,'Hola mundo.pdf'),(110,12,33,1,68,'1'),(111,12,33,1,69,'Bitácora etapa 12'),(112,12,33,1,70,'07/09/2015'),(113,12,33,1,97,'07/09/2015'),(114,12,33,1,98,'07/10/2015'),(115,12,33,1,99,''),(116,12,33,1,100,''),(117,12,33,1,101,''),(118,12,33,1,102,''),(119,12,33,1,103,''),(120,12,33,1,104,''),(121,12,33,1,105,''),(122,12,33,1,106,'07/22/2015'),(123,12,33,1,107,'07/09/2015'),(124,12,33,1,108,'07/22/2015'),(125,12,33,1,109,''),(126,12,33,1,110,''),(127,12,33,1,111,''),(128,12,33,1,112,''),(129,12,33,1,113,''),(130,12,33,1,114,''),(131,12,33,1,115,''),(132,12,33,1,71,'2'),(133,12,33,1,72,'1'),(134,13,33,1,73,'Hola mundo.pdf'),(135,13,33,1,74,'2'),(136,13,33,1,75,'2'),(137,13,33,1,76,'1'),(138,13,33,1,77,'13/08/2015'),(139,14,33,1,78,'Hola mundo.pdf'),(140,14,33,1,79,'12/08/2015'),(141,14,33,1,80,'1'),(142,14,33,1,81,'2'),(143,15,33,1,82,'Tulips.jpg'),(144,15,33,1,83,'1'),(145,15,33,1,84,'08/07/2015'),(158,16,33,1,85,'Hydrangeas.jpg'),(159,16,33,1,86,'07/14/2015'),(160,16,33,1,116,'07/02/2015'),(161,16,33,1,117,''),(162,16,33,1,118,''),(163,16,33,1,119,''),(164,16,33,1,120,''),(165,16,33,1,121,''),(166,16,33,1,122,''),(167,16,33,1,123,''),(168,16,33,1,124,''),(169,16,33,1,87,'1'),(170,17,33,1,88,'Hola mundo.pdf'),(171,17,33,1,89,'1'),(172,17,33,1,90,'09/07/2015'),(173,18,33,1,91,'Lighthouse.jpg'),(174,18,33,1,92,'1'),(175,18,33,1,93,'1'),(176,19,33,1,94,'Desert.jpg'),(177,19,33,1,95,'bitácora etapa 19'),(178,19,33,1,96,'1'),(179,20,33,1,125,'1'),(184,9,33,1,52,'Hola mundo.pdf'),(185,9,33,1,53,'2'),(186,9,33,1,54,'dfsdf'),(187,9,33,1,55,'1,2,3,'),(188,9,33,1,52,'Hola mundo.pdf'),(189,9,33,1,53,'3'),(190,9,33,1,54,'Bitácora etapa 9'),(191,9,33,1,55,'1,3,'),(192,10,33,1,56,'Hola mundo.pdf'),(193,10,33,1,57,'3'),(194,10,33,1,58,'Bitácora etapa 10'),(195,10,33,1,59,'2,3,'),(196,10,33,1,60,'2'),(197,10,33,1,61,'1'),(198,11,33,1,62,'Hola mundo.pdf'),(199,11,33,1,63,'3'),(200,11,33,1,64,'Bitácora etapa 11'),(201,11,33,1,65,'registro_fotografico'),(202,11,33,1,66,'1'),(203,11,33,1,62,'Hola mundo.pdf'),(204,11,33,1,63,'3'),(205,11,33,1,64,'B Etapa 11'),(206,11,33,1,65,'1,2,3,'),(207,11,33,1,66,'1'),(208,11,33,1,62,'Hola mundo.pdf'),(209,11,33,1,63,'4'),(210,11,33,1,64,'sdf'),(211,11,33,1,65,'registro_fotografico'),(212,11,33,1,66,'1'),(213,11,33,1,62,'Hola mundo.pdf'),(214,11,33,1,63,'4'),(215,11,33,1,64,'sdfgsdf'),(216,11,33,1,65,'123'),(217,11,33,1,66,'1'),(218,11,33,1,62,'Hola mundo.pdf'),(219,11,33,1,63,'3'),(220,11,33,1,64,'ghghfg'),(221,11,33,1,65,'1,3,'),(222,11,33,1,66,'1'),(223,11,33,1,62,'Hola mundo.pdf'),(224,11,33,1,63,'3'),(225,11,33,1,64,'sdfg'),(226,11,33,1,65,'1,2,3'),(227,11,33,1,66,'1'),(228,9,33,1,52,'Hola mundo.pdf'),(229,9,33,1,53,'2'),(230,9,33,1,54,'gsdf'),(231,9,33,1,55,'1,3'),(232,10,33,1,56,'Hola mundo.pdf'),(233,10,33,1,57,'1'),(234,10,33,1,58,'dfghdfgh'),(235,10,33,1,59,'1,2,3'),(236,10,33,1,60,'2'),(237,10,33,1,61,'1'),(238,11,33,1,62,'Hola mundo.pdf'),(239,11,33,1,63,'3'),(240,11,33,1,64,'fgdfgd'),(241,11,33,1,65,'1,2,3'),(242,11,33,1,66,'1'),(243,12,33,1,67,'Hola mundo.pdf'),(244,12,33,1,68,'4'),(245,12,33,1,69,'sdfgsdfg'),(246,12,33,1,70,'07/02/2015'),(247,12,33,1,97,'07/08/2015'),(248,12,33,1,98,''),(249,12,33,1,99,''),(250,12,33,1,100,''),(251,12,33,1,101,''),(252,12,33,1,102,''),(253,12,33,1,103,''),(254,12,33,1,104,''),(255,12,33,1,105,''),(256,12,33,1,106,'07/09/2015'),(257,12,33,1,107,'07/16/2015'),(258,12,33,1,108,''),(259,12,33,1,109,''),(260,12,33,1,110,''),(261,12,33,1,111,''),(262,12,33,1,112,''),(263,12,33,1,113,''),(264,12,33,1,114,''),(265,12,33,1,115,''),(266,12,33,1,71,'1,2,3'),(267,12,33,1,72,'1'),(268,13,33,1,73,'Hola mundo.pdf'),(269,13,33,1,74,'1,2'),(270,13,33,1,75,'1,3'),(271,13,33,1,76,'2,3'),(272,13,33,1,77,'10/07/2015'),(273,14,33,1,78,'Hola mundo.pdf'),(274,14,33,1,79,'10/07/2015'),(275,14,33,1,80,'1,3'),(276,14,33,1,81,'2,3'),(277,2,33,1,12,'02/07/2015'),(278,2,33,1,13,'Hola mundo.pdf'),(279,2,33,1,14,'1'),(280,2,33,1,15,'5 Días'),(281,2,33,1,17,'sadfsdf'),(282,2,33,1,16,'rechazar'),(333,1,39,4,1,'Proyecto 008'),(334,1,39,4,2,'Cliente 008'),(335,1,39,4,3,'Página web administrativa'),(336,1,39,4,4,'Informático'),(337,1,39,4,5,'sin_titulo.jpg'),(338,1,39,4,6,'Las Rosas 28'),(339,1,39,4,7,'12312312'),(340,1,39,4,8,'esteban.imacom@gmail.com'),(341,1,39,4,9,'16531409-3'),(342,1,39,4,10,'Escribir algo aquí\n...'),(363,1,40,4,1,'Imacon'),(364,1,40,4,2,'Esteban burgos'),(365,1,40,4,3,'Sitio web'),(366,1,40,4,4,'Plataforma web'),(367,1,40,4,5,'farolñá.jpg'),(368,1,40,4,6,'Al lado de la Municipalidad de Padre Hurtado'),(369,1,40,4,7,'77665730'),(370,1,40,4,8,'esteban.imacom@gmail.com'),(371,1,40,4,9,'11.111.111-k'),(372,1,40,4,10,'asdfasd\nsdfg'),(373,2,40,1,12,'06/07/2015'),(374,2,40,1,13,'farol.jpg'),(375,2,40,1,14,'2'),(376,2,40,1,15,'10 Días'),(377,2,40,1,17,'asdf'),(378,2,40,1,16,'rechazar'),(379,20,39,1,125,'1'),(380,2,21,5,12,'31/07/2015'),(381,2,21,5,13,'mensaje.png'),(382,2,21,5,14,'3'),(383,2,21,5,15,'5 Días'),(384,2,21,5,17,'bvnbvnvbn'),(385,2,21,5,16,'rechazar'),(386,20,39,1,125,'1'),(387,1,42,4,1,'Imacom Proyecto de prueba'),(388,1,42,4,2,'Cliente de prueba'),(389,1,42,4,3,'Tipo de proyecto de prueba'),(390,1,42,4,4,'Línea de proyecto de prueba'),(391,1,42,4,5,'farolñá.jpg'),(392,1,42,4,6,'Las Rosas 28'),(393,1,42,4,7,'1122334455'),(394,1,42,4,8,'esteban.imacom@gmail.com'),(395,1,42,4,9,'11.111.111-k'),(396,1,42,4,10,'Escribir algo aquí...\nEtapa 1.'),(397,2,42,1,12,'30/06/2015'),(398,2,42,1,13,'Tulips.jpg'),(399,2,42,1,14,'1'),(400,2,42,1,15,'10 Días'),(401,2,42,1,17,'se le envió al contratista 1 porque es mejor.'),(402,2,42,1,16,'rechazar'),(403,3,42,4,18,'30/07/2015'),(404,3,42,4,19,'farolñá.jpg'),(405,3,42,4,20,'fghdfghfhghgfhfd'),(406,3,42,4,21,'123a'),(407,3,42,4,22,'5 Días'),(408,3,42,4,23,'asdf'),(409,3,42,4,24,'asdf'),(410,3,42,4,25,'Bitácora de la etapa 3...\n...\n...\n...\n...\n'),(411,3,42,4,18,'30/07/2015'),(412,3,42,4,19,'farol.jpg'),(413,3,42,4,20,'Itemizado Genérico nombre'),(414,3,42,4,21,'Itemizado Genérico Costo'),(415,3,42,4,22,'20 Días'),(416,3,42,4,23,'Garantía de Equipo'),(417,3,42,4,24,'Garantía de Instalación'),(418,3,42,4,25,'zdfadf\nasdfasd'),(419,3,42,4,18,'30/07/2015'),(420,3,42,4,19,'farol.jpg'),(421,3,42,4,20,'Itemizado Genérico nombre'),(422,3,42,4,21,'Itemizado Genérico Costo'),(423,3,42,4,22,'20 Días'),(424,3,42,4,23,'Garantía de Equipo'),(425,3,42,4,24,'Garantía de Instalación'),(426,3,42,4,25,'zdfadf\nasdfasd'),(427,3,42,4,18,'30/07/2015'),(428,3,42,4,19,'farol.jpg'),(429,3,42,4,20,'Itemizado Genérico nombre'),(430,3,42,4,21,'Itemizado Genérico Costo'),(431,3,42,4,22,'20 Días'),(432,3,42,4,23,'Garantía de Equipo'),(433,3,42,4,24,'Garantía de Instalación'),(434,3,42,4,25,'zdfadf\nasdfasd'),(435,3,42,4,18,'02/07/2015'),(436,3,42,4,19,'farol.jpg'),(437,3,42,4,20,'Itemizado Genérico nombre'),(438,3,42,4,21,'Itemizado Genérico Costo'),(439,3,42,4,22,'15 Días'),(440,3,42,4,23,'Garantía de Equipo'),(441,3,42,4,24,'Garantía de Instalación'),(442,3,42,4,25,'dasdfasdf'),(443,3,42,4,26,'boton_rechazar'),(444,4,42,1,27,'30/07/2015'),(445,4,42,1,28,'Jellyfish.jpg'),(446,4,42,1,29,'80'),(447,4,42,1,30,'dhdhgdhg\njxslkjxz\nkjxdhkjhksj'),(448,4,42,1,31,'boton_rechazar'),(449,5,42,4,32,'08/07/2015'),(450,5,42,4,33,'Koala.jpg'),(451,5,42,4,34,'1.2'),(452,5,42,4,35,'fgsdfgd\nsdf'),(453,5,42,4,36,'boton_rechazar'),(454,6,42,4,37,'15/07/2015'),(455,6,42,4,38,'Lighthouse.jpg'),(456,6,42,4,39,'asefasdf\ndf'),(457,6,42,4,37,'08/07/2015'),(458,6,42,4,38,'farol.jpg'),(459,6,42,4,39,'sdfds'),(460,6,42,4,40,'terminar_proyecto'),(461,7,42,4,41,'21/07/2015'),(462,7,42,4,42,'farolñá.jpg'),(463,7,42,4,43,'12'),(464,7,42,4,44,'sdfdsfg'),(465,7,42,4,45,'1'),(466,8,42,1,46,'07/30/2015'),(467,8,42,1,47,'Lighthouse.jpg'),(468,8,42,1,48,'07/02/2015'),(469,8,42,1,49,'sdkjhakjs dsdasd\nñlsadkñlasd\n\nñkasdñaksdl adfsasdasnkasdkj ajsdkj'),(470,8,42,1,50,'1'),(471,8,42,1,51,'1'),(472,9,42,1,52,'prueba.docx'),(473,9,42,1,53,'7'),(474,9,42,1,54,'sdfkjsd kjfsjdk fsd f\nsd f\nsd fsdf lsdñf sdf'),(475,9,42,1,55,'1,2,3'),(476,10,42,1,56,'prueba.docx'),(477,10,42,1,57,'3'),(478,10,42,1,58,'asd as das das d\nasd asñdl asd \nasd\n as\nd a'),(479,10,42,1,59,'1,2'),(480,10,42,1,56,'prueba.docx'),(481,10,42,1,57,'3'),(482,10,42,1,58,'asd as das das d\nasd asñdl asd \nasd\n as\nd a'),(483,10,42,1,59,'1,2'),(484,10,42,1,60,'1,'),(485,10,42,1,61,'1'),(486,11,42,1,62,'prueba.docx'),(487,11,42,1,63,'3'),(488,11,42,1,64,'asdhkajshdkj\nlaskjdlkjasd\nkiasjldk kas dklas klasdj kasd'),(489,11,42,1,65,'1'),(490,11,42,1,66,'1'),(491,12,42,1,67,'prueba.docx'),(492,12,42,1,68,'4'),(493,12,42,1,69,'ihdkaj sdkjahs kjdhakjs dhasd \nKLAJSDLKJ KL\nKLAJSDKLJADKS'),(494,12,42,1,70,'08/01/2015'),(495,12,42,1,97,'08/03/2015'),(496,12,42,1,98,''),(497,12,42,1,99,''),(498,12,42,1,100,''),(499,12,42,1,101,''),(500,12,42,1,102,''),(501,12,42,1,103,''),(502,12,42,1,104,''),(503,12,42,1,105,''),(504,12,42,1,106,'08/03/2015'),(505,12,42,1,107,'08/07/2015'),(506,12,42,1,108,''),(507,12,42,1,109,''),(508,12,42,1,110,''),(509,12,42,1,111,''),(510,12,42,1,112,''),(511,12,42,1,113,''),(512,12,42,1,114,''),(513,12,42,1,115,''),(514,12,42,1,71,'1,2'),(515,12,42,1,72,'1'),(516,13,42,1,73,'prueba.docx'),(517,13,42,1,74,'1,2'),(518,13,42,1,75,'1,2'),(519,13,42,1,76,'1'),(520,13,42,1,77,'10/08/2015'),(521,14,42,1,78,'prueba.docx'),(522,14,42,1,79,'14/08/2015'),(523,14,42,1,80,'1'),(524,14,42,1,81,'1,2'),(525,15,42,1,82,'prueba.docx'),(526,15,42,1,83,'1'),(527,15,42,1,84,'17/08/2015'),(528,16,42,1,85,'prueba.docx'),(529,16,42,1,86,'08/21/2015'),(530,16,42,1,116,''),(531,16,42,1,117,''),(532,16,42,1,118,''),(533,16,42,1,119,''),(534,16,42,1,120,''),(535,16,42,1,121,''),(536,16,42,1,122,''),(537,16,42,1,123,''),(538,16,42,1,124,''),(539,16,42,1,87,'1'),(540,17,42,1,88,'prueba.docx'),(541,17,42,1,89,'1'),(542,17,42,1,90,'24/08/2015'),(543,18,42,1,91,'prueba.docx'),(544,18,42,1,92,'1'),(545,18,42,1,93,'1'),(546,19,42,1,94,'prueba.docx'),(547,19,42,1,95,'requieren soporte'),(548,19,42,1,96,'1'),(549,20,42,1,125,'1'),(550,1,48,4,1,'Proyecto 101'),(551,1,48,4,2,'Cliente 101'),(552,1,48,4,3,'Tipo 101'),(553,1,48,4,4,'Línea 101'),(554,1,48,4,5,'farol - copia.jpg'),(555,1,48,4,6,'Las Rosas 122'),(556,1,48,4,7,'77665730'),(557,1,48,4,8,'esteban.imacom@gmail.com'),(558,1,48,4,9,'16531409-3'),(559,1,48,4,10,'Bitácora etapa 1\n...'),(560,2,48,1,12,'30/07/2015'),(561,2,48,1,13,'farol - copia (2).jpg'),(562,2,48,1,14,'2'),(563,2,48,1,15,'10 Días'),(564,2,48,1,17,'Bitácora etapa 2\nasdf'),(565,2,48,1,16,'rechazar'),(566,3,48,4,18,'31/07/2015'),(567,3,48,4,19,'farol - copia (3).jpg'),(568,3,48,4,20,'Itemizado Genérico Nombre 1 101'),(569,3,48,4,126,'Itemizado Genérico Nombre 2 101'),(570,3,48,4,127,'Itemizado Genérico Nombre 3 101'),(571,3,48,4,128,'Itemizado Genérico Nombre 4 101'),(572,3,48,4,129,'Itemizado Genérico Nombre 5 101'),(573,3,48,4,130,'Itemizado Genérico Nombre 6 101'),(574,3,48,4,131,'Itemizado Genérico Nombre 7 101'),(575,3,48,4,132,''),(576,3,48,4,133,''),(577,3,48,4,134,''),(578,3,48,4,21,'10000'),(579,3,48,4,22,'10 Días'),(580,3,48,4,23,'Garantía Equipo 101'),(581,3,48,4,24,'Garantía Instalación 101'),(582,3,48,4,25,'Bitácora etapa 3\nñ\n\n\n....'),(583,3,48,4,26,'boton_rechazar'),(602,4,48,1,27,'06/08/2015'),(603,4,48,1,28,'farol - copia (4).jpg'),(604,4,48,1,29,'12'),(605,4,48,1,30,'Bitácora etapa 4'),(606,4,48,1,31,'boton_rechazar'),(612,5,48,4,32,'05/08/2015'),(613,5,48,4,33,'farol - copia (5).jpg'),(614,5,48,4,34,'12'),(615,5,48,4,35,'Bitácora etapa 5'),(616,5,48,4,36,'boton_rechazar'),(617,6,48,4,37,'05/08/2015'),(618,6,48,4,38,'farol - copia (6).jpg'),(619,6,48,4,39,'Bitácora etapa 6'),(620,6,48,4,40,'terminar_proyecto'),(626,7,48,4,41,'06/08/2015'),(627,7,48,4,42,'farol - copia (7).jpg'),(628,7,48,4,43,'15'),(629,7,48,4,44,'Bitácora etapa 7'),(630,7,48,4,45,'1'),(631,8,48,1,46,'07/31/2015'),(632,8,48,1,47,'farol - copia (8).jpg'),(633,8,48,1,48,'08/05/2015'),(634,8,48,1,49,'Bitácora etapa 8'),(635,8,48,1,50,'1'),(636,8,48,1,51,'1'),(637,9,48,1,52,'farol - copia (9).jpg'),(638,9,48,1,53,'2'),(639,9,48,1,54,'Bitácora etapa 9'),(640,9,48,1,55,'1,3'),(641,10,48,1,56,'farol - copia (10).jpg'),(642,10,48,1,57,'4'),(643,10,48,1,58,'Bitácora etapa 10'),(644,10,48,1,59,'2'),(645,10,48,1,60,'1,3,'),(646,10,48,1,61,'1'),(647,11,48,1,62,'farol - copia (11).jpg'),(648,11,48,1,63,'1'),(649,11,48,1,64,'Bitácora etapa 11'),(650,11,48,1,65,'1,3'),(651,11,48,1,66,'1'),(722,12,48,1,67,'farol - copia (12).jpg'),(723,12,48,1,68,'12'),(724,12,48,1,69,'Bitácora etapa 12'),(725,12,48,1,135,'Nombre 101'),(726,12,48,1,136,''),(727,12,48,1,137,''),(728,12,48,1,138,''),(729,12,48,1,139,''),(730,12,48,1,140,''),(731,12,48,1,141,''),(732,12,48,1,142,''),(733,12,48,1,143,''),(734,12,48,1,144,''),(735,12,48,1,70,'08/30/2015'),(736,12,48,1,97,''),(737,12,48,1,98,''),(738,12,48,1,99,''),(739,12,48,1,100,''),(740,12,48,1,101,''),(741,12,48,1,102,''),(742,12,48,1,103,''),(743,12,48,1,104,''),(744,12,48,1,105,''),(745,12,48,1,106,'09/01/2015'),(746,12,48,1,107,''),(747,12,48,1,108,''),(748,12,48,1,109,''),(749,12,48,1,110,''),(750,12,48,1,111,''),(751,12,48,1,112,''),(752,12,48,1,113,''),(753,12,48,1,114,''),(754,12,48,1,115,''),(755,12,48,1,71,'1,3'),(756,12,48,1,72,'1'),(757,13,48,1,73,'farol - copia (13).jpg'),(758,13,48,1,74,'1,3'),(759,13,48,1,75,'1,2'),(760,13,48,1,76,'2,3'),(761,13,48,1,77,'31/08/2015'),(762,14,48,1,78,'farol - copia (13).jpg'),(763,14,48,1,79,'01/09/2015'),(764,14,48,1,80,'1,2'),(765,14,48,1,81,'2,3'),(766,15,48,1,82,'farol - copia (15).jpg'),(767,15,48,1,83,'1'),(768,15,48,1,84,'03/09/2015'),(769,16,48,1,85,'farol - copia (16).jpg'),(770,16,48,1,85,'farol - copia (16).jpg'),(771,16,48,1,145,'Nombre 101 16'),(772,16,48,1,146,''),(773,16,48,1,147,''),(774,16,48,1,148,''),(775,16,48,1,149,''),(776,16,48,1,150,''),(777,16,48,1,151,''),(778,16,48,1,152,''),(779,16,48,1,153,''),(780,16,48,1,154,''),(781,16,48,1,86,'08/20/2015'),(782,16,48,1,116,''),(783,16,48,1,117,''),(784,16,48,1,118,''),(785,16,48,1,119,''),(786,16,48,1,120,''),(787,16,48,1,121,''),(788,16,48,1,122,''),(789,16,48,1,123,''),(790,16,48,1,124,''),(791,16,48,1,87,'1'),(1025,1,49,4,1,'proyecto testing'),(1026,1,49,4,2,'imacom testing'),(1027,1,49,4,3,'tipo de proyecto'),(1028,1,49,4,4,'linea de negocio'),(1029,1,49,4,5,'testing.docx'),(1030,1,49,4,6,'las rosas 28'),(1031,1,49,4,7,'222222222'),(1032,1,49,4,8,'soporte@imacom.cl'),(1033,1,49,4,9,'888888888'),(1034,1,49,4,10,'Este es el ingreso del proyecto'),(1035,2,49,5,12,'21/08/2015'),(1036,2,49,5,13,'testing.docx'),(1037,2,49,5,14,'2'),(1038,2,49,5,15,'5 Días'),(1039,2,49,5,17,'Cras quis ante magna. Ut libero ex, aliquam a velit vel, luctus tempus libero. Phasellus mattis quis ante eget ullamcorper. Etiam ut tincidunt eros, quis imperdiet nunc. Mauris dictum eros a tortor imperdiet, id rhoncus urna placerat.'),(1040,2,49,5,16,'rechazar'),(1041,3,49,4,18,'29/08/2015'),(1042,3,49,4,19,'testing.docx'),(1043,3,49,4,20,'23423'),(1044,3,49,4,126,'234234'),(1045,3,49,4,127,'werwer'),(1046,3,49,4,128,'3542352'),(1047,3,49,4,129,''),(1048,3,49,4,130,''),(1049,3,49,4,131,''),(1050,3,49,4,132,''),(1051,3,49,4,133,''),(1052,3,49,4,134,''),(1053,3,49,4,21,'3000000'),(1054,3,49,4,22,'5 Días'),(1055,3,49,4,23,'sdcazsdasd'),(1056,3,49,4,24,'asdasdasd'),(1057,3,49,4,25,'asdasdas adfsdgfdfg nvhvhmhm'),(1058,3,49,4,26,'boton_rechazar'),(1059,4,49,5,27,'29/08/2015'),(1060,4,49,5,28,'testing.docx'),(1061,4,49,5,29,'11.9'),(1062,4,49,5,30,'asdkkl jaasdj aksjd ai8ur qdkiajlsdkijlak'),(1063,4,49,5,31,'boton_rechazar'),(1064,5,49,4,32,'29/08/2015'),(1065,5,49,4,33,'testing.docx'),(1066,5,49,4,34,'5.5'),(1067,5,49,4,35,'sdfs dsdf sdf r4t354tegvs dgsr sg'),(1068,5,49,4,36,'boton_rechazar'),(1069,6,49,4,37,'30/08/2015'),(1070,6,49,4,38,'testing.docx'),(1071,6,49,4,39,'dsfsed s fsdef ws4fe wgfw swedf wef'),(1072,6,49,4,40,'terminar_proyecto'),(1073,7,49,4,41,'31/08/2015'),(1074,7,49,4,42,'testing.docx'),(1075,7,49,4,43,'6.0'),(1076,7,49,4,44,'asda sd aaeds fegrt4 vezagae5gzdf'),(1077,7,49,4,45,'1'),(1078,8,49,5,46,'09/01/2015'),(1079,8,49,5,47,'testing.docx'),(1080,8,49,5,48,'09/03/2015'),(1081,8,49,5,49,'hkwadkj hakjsdh kjahskjd 9i3oirasl djalksd kas'),(1082,8,49,5,50,'1'),(1083,8,49,5,51,'1'),(1084,9,49,5,52,'testing.docx'),(1085,9,49,5,53,'3'),(1086,9,49,5,54,'jasdhjg aksj dhkjahs askjd jkasjdkjasdk'),(1087,9,49,5,55,'1,2'),(1088,10,49,5,56,'testing.docx'),(1089,10,49,5,57,'3'),(1090,10,49,5,58,'jawdlskj aksd kjlajksdj askdajd klasd '),(1091,10,49,5,59,'1,2'),(1092,10,49,5,60,'1,'),(1093,10,49,5,61,'1'),(1094,11,49,5,62,'testing.docx'),(1095,11,49,5,63,'4'),(1096,11,49,5,64,'kjakjshdlKJASLKJalks'),(1097,11,49,5,65,'1,2'),(1098,11,49,5,66,'1'),(1099,12,49,5,67,'testing.docx'),(1100,12,49,5,68,'1'),(1101,12,49,5,69,'kasjdklasd adks lkasdlkas kdaskd klaksld'),(1102,12,49,5,135,'item 1a'),(1103,12,49,5,136,''),(1104,12,49,5,137,''),(1105,12,49,5,138,''),(1106,12,49,5,139,''),(1107,12,49,5,140,''),(1108,12,49,5,141,''),(1109,12,49,5,142,''),(1110,12,49,5,143,''),(1111,12,49,5,144,''),(1112,12,49,5,70,'09/03/2015'),(1113,12,49,5,97,''),(1114,12,49,5,98,''),(1115,12,49,5,99,''),(1116,12,49,5,100,''),(1117,12,49,5,101,''),(1118,12,49,5,102,''),(1119,12,49,5,103,''),(1120,12,49,5,104,''),(1121,12,49,5,105,''),(1122,12,49,5,106,'09/05/2015'),(1123,12,49,5,107,''),(1124,12,49,5,108,''),(1125,12,49,5,109,''),(1126,12,49,5,110,''),(1127,12,49,5,111,''),(1128,12,49,5,112,''),(1129,12,49,5,113,''),(1130,12,49,5,114,''),(1131,12,49,5,115,''),(1132,12,49,5,71,'1'),(1133,12,49,5,67,'testing.docx'),(1134,12,49,5,68,'1'),(1135,12,49,5,69,'kasjdklasd adks lkasdlkas kdaskd klaksld'),(1136,12,49,5,135,'item 1a'),(1137,12,49,5,136,''),(1138,12,49,5,137,''),(1139,12,49,5,138,''),(1140,12,49,5,139,''),(1141,12,49,5,140,''),(1142,12,49,5,141,''),(1143,12,49,5,142,''),(1144,12,49,5,143,''),(1145,12,49,5,144,''),(1146,12,49,5,70,'09/03/2015'),(1147,12,49,5,97,''),(1148,12,49,5,98,''),(1149,12,49,5,99,''),(1150,12,49,5,100,''),(1151,12,49,5,101,''),(1152,12,49,5,102,''),(1153,12,49,5,103,''),(1154,12,49,5,104,''),(1155,12,49,5,105,''),(1156,12,49,5,106,'09/05/2015'),(1157,12,49,5,107,''),(1158,12,49,5,108,''),(1159,12,49,5,109,''),(1160,12,49,5,110,''),(1161,12,49,5,111,''),(1162,12,49,5,112,''),(1163,12,49,5,113,''),(1164,12,49,5,114,''),(1165,12,49,5,115,''),(1166,12,49,5,71,'1'),(1167,12,49,1,67,'holamundo.jpg'),(1168,12,49,1,68,'5'),(1169,12,49,1,69,'Bitácora de prueba 01'),(1170,12,49,1,135,'nombre de prueba genérico 01'),(1171,12,49,1,136,''),(1172,12,49,1,137,''),(1173,12,49,1,138,''),(1174,12,49,1,139,''),(1175,12,49,1,140,''),(1176,12,49,1,141,''),(1177,12,49,1,142,''),(1178,12,49,1,143,''),(1179,12,49,1,144,''),(1180,12,49,1,70,'08/26/2015'),(1181,12,49,1,97,''),(1182,12,49,1,98,''),(1183,12,49,1,99,''),(1184,12,49,1,100,''),(1185,12,49,1,101,''),(1186,12,49,1,102,''),(1187,12,49,1,103,''),(1188,12,49,1,104,''),(1189,12,49,1,105,''),(1190,12,49,1,106,'08/31/2015'),(1191,12,49,1,107,''),(1192,12,49,1,108,''),(1193,12,49,1,109,''),(1194,12,49,1,110,''),(1195,12,49,1,111,''),(1196,12,49,1,112,''),(1197,12,49,1,113,''),(1198,12,49,1,114,''),(1199,12,49,1,115,''),(1200,12,49,1,71,'2'),(1201,12,49,1,72,'1'),(1202,12,49,1,67,'holamundo.jpg'),(1203,12,49,1,68,'5'),(1204,12,49,1,69,'Bitácora de prueba 01'),(1205,12,49,1,135,'nombre de prueba genérico 01'),(1206,12,49,1,136,''),(1207,12,49,1,137,''),(1208,12,49,1,138,''),(1209,12,49,1,139,''),(1210,12,49,1,140,''),(1211,12,49,1,141,''),(1212,12,49,1,142,''),(1213,12,49,1,143,''),(1214,12,49,1,144,''),(1215,12,49,1,70,'08/26/2015'),(1216,12,49,1,97,''),(1217,12,49,1,98,''),(1218,12,49,1,99,''),(1219,12,49,1,100,''),(1220,12,49,1,101,''),(1221,12,49,1,102,''),(1222,12,49,1,103,''),(1223,12,49,1,104,''),(1224,12,49,1,105,''),(1225,12,49,1,106,'08/31/2015'),(1226,12,49,1,107,''),(1227,12,49,1,108,''),(1228,12,49,1,109,''),(1229,12,49,1,110,''),(1230,12,49,1,111,''),(1231,12,49,1,112,''),(1232,12,49,1,113,''),(1233,12,49,1,114,''),(1234,12,49,1,115,''),(1235,12,49,1,71,'2'),(1236,12,49,1,67,'holamundo.jpg'),(1237,12,49,1,68,'4'),(1238,12,49,1,69,'vsgv'),(1239,12,49,1,135,'zzxcv'),(1240,12,49,1,136,''),(1241,12,49,1,137,''),(1242,12,49,1,138,''),(1243,12,49,1,139,''),(1244,12,49,1,140,''),(1245,12,49,1,141,''),(1246,12,49,1,142,''),(1247,12,49,1,143,''),(1248,12,49,1,144,''),(1249,12,49,1,70,'08/04/2015'),(1250,12,49,1,97,''),(1251,12,49,1,98,''),(1252,12,49,1,99,''),(1253,12,49,1,100,''),(1254,12,49,1,101,''),(1255,12,49,1,102,''),(1256,12,49,1,103,''),(1257,12,49,1,104,''),(1258,12,49,1,105,''),(1259,12,49,1,106,'08/18/2015'),(1260,12,49,1,107,''),(1261,12,49,1,108,''),(1262,12,49,1,109,''),(1263,12,49,1,110,''),(1264,12,49,1,111,''),(1265,12,49,1,112,''),(1266,12,49,1,113,''),(1267,12,49,1,114,''),(1268,12,49,1,115,''),(1269,12,49,1,71,''),(1270,12,49,1,72,''),(1271,12,49,1,67,'holamundo.jpg'),(1272,12,49,1,68,'4'),(1273,12,49,1,69,'vsgv'),(1274,12,49,1,135,'zzxcv'),(1275,12,49,1,136,''),(1276,12,49,1,137,''),(1277,12,49,1,138,''),(1278,12,49,1,139,''),(1279,12,49,1,140,''),(1280,12,49,1,141,''),(1281,12,49,1,142,''),(1282,12,49,1,143,''),(1283,12,49,1,144,''),(1284,12,49,1,70,'08/04/2015'),(1285,12,49,1,97,''),(1286,12,49,1,98,''),(1287,12,49,1,99,''),(1288,12,49,1,100,''),(1289,12,49,1,101,''),(1290,12,49,1,102,''),(1291,12,49,1,103,''),(1292,12,49,1,104,''),(1293,12,49,1,105,''),(1294,12,49,1,106,'08/18/2015'),(1295,12,49,1,107,''),(1296,12,49,1,108,''),(1297,12,49,1,109,''),(1298,12,49,1,110,''),(1299,12,49,1,111,''),(1300,12,49,1,112,''),(1301,12,49,1,113,''),(1302,12,49,1,114,''),(1303,12,49,1,115,''),(1304,12,49,1,71,''),(1305,12,49,1,72,NULL),(1306,7,21,1,41,'05/08/2015'),(1307,7,21,1,42,'holamundo.jpg'),(1308,7,21,1,43,'12'),(1309,7,21,1,44,'bitacora 07'),(1310,7,21,1,45,NULL),(1311,3,42,1,18,'12/08/2015'),(1312,3,42,1,19,'holamundo.jpg'),(1313,3,42,1,20,'nombre de prueba genérico 01'),(1314,3,42,1,126,''),(1315,3,42,1,127,''),(1316,3,42,1,128,''),(1317,3,42,1,129,''),(1318,3,42,1,130,''),(1319,3,42,1,131,''),(1320,3,42,1,132,''),(1321,3,42,1,133,''),(1322,3,42,1,134,''),(1323,3,42,1,21,'12'),(1324,3,42,1,22,'10 Días'),(1325,3,42,1,23,'Garantía de Equipo'),(1326,3,42,1,24,'Garantía de Instalación'),(1327,3,42,1,25,'bitácora 03'),(1328,3,42,1,26,'boton_rechazar'),(1329,7,21,1,41,'02/09/2015'),(1330,7,21,1,42,'holamundo.jpg'),(1331,7,21,1,43,'12'),(1332,7,21,1,44,'asdfsdf'),(1333,7,21,1,45,'0'),(1334,7,21,1,41,'02/09/2015'),(1335,7,21,1,42,'holamundo.jpg'),(1336,7,21,1,43,'12'),(1337,7,21,1,44,'asdf'),(1338,7,21,1,45,'0'),(1339,7,21,1,41,'20/08/2015'),(1340,7,21,1,42,'holamundo.jpg'),(1341,7,21,1,43,'12'),(1342,7,21,1,44,'asdf'),(1343,7,21,1,45,NULL),(1344,7,21,1,41,'17/09/2015'),(1345,7,21,1,42,'holamundo.jpg'),(1346,7,21,1,43,'12'),(1347,7,21,1,44,'sdf'),(1348,7,21,1,45,NULL),(1349,7,21,1,41,'08/09/2015'),(1350,7,21,1,42,'holamundo.jpg'),(1351,7,21,1,43,'12'),(1352,7,21,1,44,'asdf'),(1353,7,21,1,45,NULL),(1354,7,21,1,41,'07/08/2015'),(1355,7,21,1,42,'holamundo.jpg'),(1356,7,21,1,43,'12'),(1357,7,21,1,44,'asdf'),(1358,7,21,1,45,NULL),(1359,7,21,1,41,'10/08/2015'),(1360,7,21,1,42,'holamundo.jpg'),(1361,7,21,1,43,'12'),(1362,7,21,1,44,'123'),(1363,7,21,1,45,NULL),(1364,7,21,1,41,'30/07/2015'),(1365,7,21,1,42,'holamundo.jpg'),(1366,7,21,1,43,'12'),(1367,7,21,1,44,'sdf'),(1368,7,21,1,45,NULL),(1369,7,21,1,41,'17/08/2015'),(1370,7,21,1,42,'holamundo.jpg'),(1371,7,21,1,43,'12'),(1372,7,21,1,44,'asdf'),(1373,7,21,1,45,'0'),(1374,7,21,1,41,'19/08/2015'),(1375,7,21,1,42,'holamundo.jpg'),(1376,7,21,1,43,'34123'),(1377,7,21,1,44,'asdf'),(1378,7,21,1,45,'0'),(1379,7,21,1,41,'06/08/2015'),(1380,7,21,1,42,'holamundo.jpg'),(1381,7,21,1,43,'12'),(1382,7,21,1,44,'asdf'),(1383,7,21,1,45,'0'),(1384,7,21,1,41,'06/08/2015'),(1385,7,21,1,42,'holamundo.jpg'),(1386,7,21,1,43,'12'),(1387,7,21,1,44,'asdf'),(1388,7,21,1,45,'0'),(1389,7,21,1,41,'11/09/2015'),(1390,7,21,1,42,'holamundo.jpg'),(1391,7,21,1,43,'12'),(1392,7,21,1,44,'asdf'),(1393,7,21,1,45,'0'),(1394,1,50,4,1,'Testing 002'),(1395,1,50,4,2,'Cliente testing'),(1396,1,50,4,3,'Tipo de proyecto testing'),(1397,1,50,4,4,'Linea de negocio testing'),(1398,1,50,4,5,'holamundo.txt'),(1399,1,50,4,6,'Dirección 01'),(1400,1,50,4,7,'02-22334433'),(1401,1,50,4,8,'esteban.imacom@gmail.com'),(1402,1,50,4,9,'16531409-3'),(1403,1,50,4,10,'Bitácora 01'),(1404,2,50,1,12,'02/09/2015'),(1405,2,50,1,13,'holamundo.txt'),(1406,2,50,1,14,'2'),(1407,2,50,1,15,'10 Días'),(1408,2,50,1,17,'Bitácora 02'),(1409,2,50,1,16,'rechazar'),(1410,3,50,4,18,'03/09/2015'),(1411,3,50,4,19,'holamundo.txt'),(1412,3,50,4,20,'itemizado genérico nombre testing'),(1413,3,50,4,126,''),(1414,3,50,4,127,''),(1415,3,50,4,128,''),(1416,3,50,4,129,''),(1417,3,50,4,130,''),(1418,3,50,4,131,''),(1419,3,50,4,132,''),(1420,3,50,4,133,''),(1421,3,50,4,134,''),(1422,3,50,4,21,'121'),(1423,3,50,4,22,'15 Días'),(1424,3,50,4,23,'Garantia equipo testing'),(1425,3,50,4,24,'garantia instalación testing'),(1426,3,50,4,25,'Bitácora 03'),(1427,3,50,4,26,'boton_rechazar'),(1428,4,50,1,27,'03/09/2015'),(1429,4,50,1,28,'holamundo.txt'),(1430,4,50,1,29,'122'),(1431,4,50,1,30,'Bitácora 04'),(1432,4,50,1,31,'boton_rechazar'),(1433,5,50,4,32,'09/09/2015'),(1434,5,50,4,33,'holamundo.txt'),(1435,5,50,4,34,'54'),(1436,5,50,4,35,'Bitácora 05'),(1437,5,50,4,36,'boton_rechazar'),(1438,6,50,4,37,'02/09/2015'),(1439,6,50,4,38,'holamundo.txt'),(1440,6,50,4,39,'Bitácora 06'),(1441,6,50,4,40,'terminar_proyecto'),(1447,7,50,4,41,'09/09/2015'),(1448,7,50,4,42,'holamundo.txt'),(1449,7,50,4,43,'12'),(1450,7,50,4,44,'bitácora 07'),(1451,7,50,4,45,'1'),(1452,8,50,1,46,'08/07/2015'),(1453,8,50,1,47,'holamundo.txt'),(1454,8,50,1,48,'09/03/2015'),(1455,8,50,1,49,'bitácora 08'),(1456,8,50,1,50,'1'),(1457,8,50,1,51,'1'),(1462,9,50,1,52,'holamundo.txt'),(1463,9,50,1,53,'2'),(1464,9,50,1,54,'bitácora 09'),(1465,9,50,1,55,'0,1,3'),(1466,15,49,5,82,'testing.docx'),(1467,15,49,5,83,'0'),(1468,15,49,5,84,'04/09/2015'),(1469,16,49,5,85,'testing.docx'),(1470,16,49,5,145,'asdasdas'),(1471,16,49,5,146,''),(1472,16,49,5,147,''),(1473,16,49,5,148,''),(1474,16,49,5,149,''),(1475,16,49,5,150,''),(1476,16,49,5,151,''),(1477,16,49,5,152,''),(1478,16,49,5,153,''),(1479,16,49,5,154,''),(1480,16,49,5,86,'09/03/2015'),(1481,16,49,5,116,''),(1482,16,49,5,117,''),(1483,16,49,5,118,''),(1484,16,49,5,119,''),(1485,16,49,5,120,''),(1486,16,49,5,121,''),(1487,16,49,5,122,''),(1488,16,49,5,123,''),(1489,16,49,5,124,''),(1490,16,49,5,87,'1'),(1491,17,49,5,88,'testing.docx'),(1492,17,49,5,89,'1'),(1493,17,49,5,90,'07/09/2015'),(1500,18,49,5,91,'holamundo.jpg'),(1501,18,49,5,92,'1'),(1502,18,49,5,93,'1'),(1503,19,49,5,94,'holamundo.jpg'),(1504,19,49,5,95,'Bitácora 19'),(1505,19,49,5,96,'1'),(1508,20,49,5,125,'1'),(1509,10,50,1,56,'holamundo.jpg'),(1510,10,50,1,57,'3'),(1511,10,50,1,58,'Bitácora 10'),(1512,10,50,1,59,'0,2,3'),(1513,10,50,1,60,'0,1,2,'),(1514,10,50,1,61,'1'),(1515,11,50,1,62,'holamundo.jpg'),(1516,11,50,1,63,'4'),(1517,11,50,1,64,'Bitácora 11'),(1518,11,50,1,65,'0,2'),(1519,11,50,1,66,'1'),(1542,1,51,4,1,'Testing 03'),(1543,1,51,4,2,'Cliente testing 03'),(1544,1,51,4,3,'Tipo de proyecto testing 03'),(1545,1,51,4,4,'Línea de Negocio testing 03'),(1546,1,51,4,5,'holamundo.jpg'),(1547,1,51,4,6,'Dirección testing 03'),(1548,1,51,4,7,'2 - 1122334455'),(1549,1,51,4,8,'esteban.imacom@gmail.com'),(1550,1,51,4,9,'11.111.111-k'),(1551,1,51,4,10,'Bitácora 01'),(1552,2,51,1,12,'02/09/2015'),(1553,2,51,1,13,'holamundo.jpg'),(1554,2,51,1,14,'1'),(1555,2,51,1,15,'5 Días'),(1556,2,51,1,17,'Bitácora 02'),(1557,2,51,1,16,'rechazar'),(1558,3,51,4,18,'03/09/2015'),(1559,3,51,4,19,'holamundo.jpg'),(1560,3,51,4,20,'Itemizado Genérico Nombre 03'),(1561,3,51,4,126,''),(1562,3,51,4,127,''),(1563,3,51,4,128,''),(1564,3,51,4,129,''),(1565,3,51,4,130,''),(1566,3,51,4,131,''),(1567,3,51,4,132,''),(1568,3,51,4,133,''),(1569,3,51,4,134,''),(1570,3,51,4,21,'123456'),(1571,3,51,4,22,'5 Días'),(1572,3,51,4,23,'Garantía equipo 03'),(1573,3,51,4,24,'Garantía de Instalación 03'),(1574,3,51,4,25,'Bitácora 03'),(1575,3,51,4,26,'boton_rechazar'),(1576,4,51,1,27,'04/09/2015'),(1577,4,51,1,28,'holamundo.jpg'),(1578,4,51,1,29,'10,01'),(1579,4,51,1,30,'Bitácora 04'),(1580,4,51,1,31,'boton_rechazar'),(1581,5,51,4,32,'09/09/2015'),(1582,5,51,4,33,'holamundo.jpg'),(1583,5,51,4,34,'10,01'),(1584,5,51,4,35,'Bitácora 05'),(1585,5,51,4,36,'boton_rechazar'),(1586,6,51,4,37,'09/09/2015'),(1587,6,51,4,38,'holamundo.jpg'),(1588,6,51,4,39,'Bitácora 06'),(1589,6,51,4,40,'terminar_proyecto'),(1590,7,51,4,41,'07/09/2015'),(1591,7,51,4,42,'holamundo.jpg'),(1592,7,51,4,43,'12'),(1593,7,51,4,44,'Bitácora 07'),(1594,7,51,4,45,'1'),(1595,8,51,1,46,'09/03/2015'),(1596,8,51,1,47,'holamundo.jpg'),(1597,8,51,1,48,'09/03/2015'),(1598,8,51,1,49,'Bitácora 08'),(1599,8,51,1,50,'1'),(1600,8,51,1,51,'1'),(1601,9,51,1,52,'holamundo.jpg'),(1602,9,51,1,53,'2'),(1603,9,51,1,54,'Bitácora 09'),(1604,9,51,1,55,'0,1,3'),(1605,10,51,1,56,'holamundo.jpg'),(1606,10,51,1,57,'3'),(1607,10,51,1,58,'Bitácora 11'),(1608,10,51,1,59,'0,2'),(1609,10,51,1,60,'0,1,'),(1610,10,51,1,61,'1'),(1611,11,51,1,62,'holamundo.jpg'),(1612,11,51,1,63,'5'),(1613,11,51,1,64,'Bitácora 11'),(1614,11,51,1,65,'0,1,3'),(1615,11,51,1,66,'0'),(1616,12,51,1,67,'holamundo.jpg'),(1617,12,51,1,68,'2'),(1618,12,51,1,69,'Bitácora 12'),(1619,12,51,1,135,'Itemizado Genérico Nombre 1 testing'),(1620,12,51,1,136,''),(1621,12,51,1,137,''),(1622,12,51,1,138,''),(1623,12,51,1,139,''),(1624,12,51,1,140,''),(1625,12,51,1,141,''),(1626,12,51,1,142,''),(1627,12,51,1,143,''),(1628,12,51,1,144,''),(1629,12,51,1,70,'09/02/2015'),(1630,12,51,1,97,''),(1631,12,51,1,98,''),(1632,12,51,1,99,''),(1633,12,51,1,100,''),(1634,12,51,1,101,''),(1635,12,51,1,102,''),(1636,12,51,1,103,''),(1637,12,51,1,104,''),(1638,12,51,1,105,''),(1639,12,51,1,106,'09/03/2015'),(1640,12,51,1,107,''),(1641,12,51,1,108,''),(1642,12,51,1,109,''),(1643,12,51,1,110,''),(1644,12,51,1,111,''),(1645,12,51,1,112,''),(1646,12,51,1,113,''),(1647,12,51,1,114,''),(1648,12,51,1,115,''),(1649,12,51,1,71,'0,2,3'),(1650,12,51,1,72,'1'),(1651,13,51,1,73,'holamundo.jpg'),(1652,13,51,1,74,'0,2'),(1653,13,51,1,75,'0,2'),(1654,13,51,1,76,'0,3'),(1655,13,51,1,77,'16/09/2015'),(1656,14,51,1,78,'holamundo.jpg'),(1657,14,51,1,79,'03/09/2015'),(1658,14,51,1,80,'0,2'),(1659,14,51,1,81,'0,2'),(1660,12,50,1,67,'holamundo.jpg'),(1661,12,50,1,68,'3'),(1662,12,50,1,69,'fgj'),(1663,12,50,1,135,'fj'),(1664,12,50,1,136,''),(1665,12,50,1,137,''),(1666,12,50,1,138,''),(1667,12,50,1,139,''),(1668,12,50,1,140,''),(1669,12,50,1,141,''),(1670,12,50,1,142,''),(1671,12,50,1,143,''),(1672,12,50,1,144,''),(1673,12,50,1,70,'09/02/2015'),(1674,12,50,1,97,''),(1675,12,50,1,98,''),(1676,12,50,1,99,''),(1677,12,50,1,100,''),(1678,12,50,1,101,''),(1679,12,50,1,102,''),(1680,12,50,1,103,''),(1681,12,50,1,104,''),(1682,12,50,1,105,''),(1683,12,50,1,106,'09/03/2015'),(1684,12,50,1,107,''),(1685,12,50,1,108,''),(1686,12,50,1,109,''),(1687,12,50,1,110,''),(1688,12,50,1,111,''),(1689,12,50,1,112,''),(1690,12,50,1,113,''),(1691,12,50,1,114,''),(1692,12,50,1,115,''),(1693,12,50,1,71,'0,1,3'),(1694,12,50,1,72,'1'),(1695,13,50,1,73,'holamundo.jpg'),(1696,13,50,1,74,'0,2'),(1697,13,50,1,75,'0,1,3'),(1698,13,50,1,76,'0,2'),(1699,13,50,1,77,'09/09/2015'),(1700,14,50,1,78,'holamundo.jpg'),(1701,14,50,1,79,'10/09/2015'),(1702,14,50,1,80,'0,2'),(1703,14,50,1,81,'0,1,3'),(1704,15,50,1,82,'holamundo.jpg'),(1705,15,50,1,83,'1'),(1706,15,50,1,84,'17/09/2015'),(1707,15,51,1,82,'holamundo.jpg'),(1708,15,51,1,83,'1'),(1709,15,51,1,84,'10/09/2015'),(1732,16,50,1,85,'holamundo.jpg'),(1733,16,50,1,145,'nombre testing'),(1734,16,50,1,146,''),(1735,16,50,1,147,''),(1736,16,50,1,148,''),(1737,16,50,1,149,''),(1738,16,50,1,150,''),(1739,16,50,1,151,''),(1740,16,50,1,152,''),(1741,16,50,1,153,''),(1742,16,50,1,154,''),(1743,16,50,1,86,'09/10/2015'),(1744,16,50,1,116,''),(1745,16,50,1,117,''),(1746,16,50,1,118,''),(1747,16,50,1,119,''),(1748,16,50,1,120,''),(1749,16,50,1,121,''),(1750,16,50,1,122,''),(1751,16,50,1,123,''),(1752,16,50,1,124,''),(1753,16,50,1,87,'1'),(1754,17,50,1,88,'holamundo.jpg'),(1755,17,50,1,89,'1'),(1756,17,50,1,90,'09/09/2015'),(1757,18,50,1,91,'holamundo.jpg'),(1758,18,50,1,92,'1'),(1759,18,50,1,93,'1'),(1760,19,50,1,94,'holamundo.jpg'),(1761,19,50,1,95,'Bitácora 19'),(1762,19,50,1,96,'1'),(1763,20,50,1,125,'1'),(1774,1,35,4,1,'Proyecto 0007'),(1775,1,35,4,2,'Cliente 0007'),(1776,1,35,4,3,'Tipo de proyecto 007'),(1777,1,35,4,4,'2'),(1778,1,35,4,5,'holamundo.jpg'),(1779,1,35,4,6,'asdfasdf'),(1780,1,35,4,7,'77665730'),(1781,1,35,4,8,'esteban.imacom@gmail.com'),(1782,1,35,4,9,'11.111.111-k'),(1783,1,35,4,10,'bitácora 01111'),(1784,1,55,4,1,'Proyecto de prueba 01'),(1785,1,55,4,2,'Cliente de prueba 01'),(1786,1,55,4,3,'Tipo de proyecto 01'),(1787,1,55,4,4,'Línea de proyecto 01'),(1788,1,55,4,5,'hola1.jpg'),(1789,1,55,4,6,'Dirección 01'),(1790,1,55,4,7,'123123123'),(1791,1,55,4,8,'usuario@chilectra.cl'),(1792,1,55,4,9,'12.345.789-K'),(1793,1,55,4,10,'Bitácora 001'),(1794,2,55,1,12,'14/04/2016'),(1795,2,55,1,13,'hola2.jpg'),(1796,2,55,1,14,'1'),(1797,2,55,1,15,'5 Días'),(1798,2,55,1,17,'Bitácora 02'),(1799,2,55,1,16,'rechazar'),(1800,3,55,4,18,'22/04/2016'),(1801,3,55,4,19,'hola4.jpg'),(1802,3,55,4,20,'Itemizado Genérico 01'),(1803,3,55,4,126,'Itemizado Genérico 02'),(1804,3,55,4,127,'Itemizado Genérico 03'),(1805,3,55,4,128,''),(1806,3,55,4,129,''),(1807,3,55,4,130,''),(1808,3,55,4,131,''),(1809,3,55,4,132,''),(1810,3,55,4,133,''),(1811,3,55,4,134,''),(1812,3,55,4,21,'1001'),(1813,3,55,4,22,'5 Días'),(1814,3,55,4,23,'Garantía 01'),(1815,3,55,4,24,'Garantía de instalación 01'),(1816,3,55,4,25,'Bitácora 04'),(1817,3,55,4,26,'boton_rechazar'),(1818,4,55,1,27,'25/04/2016'),(1819,4,55,1,28,'hola5.jpg'),(1820,4,55,1,29,'10,01'),(1821,4,55,1,30,'Bitácora 05'),(1822,4,55,1,31,'boton_rechazar'),(1823,5,55,4,32,'26/04/2016'),(1824,5,55,4,33,'hola5.jpg'),(1825,5,55,4,34,'11'),(1826,5,55,4,35,'Bitácora 05'),(1827,5,55,4,36,'boton_rechazar');
/*!40000 ALTER TABLE `etapas_v2_campos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `logs`
--

DROP TABLE IF EXISTS `logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `logs` (
  `log_id` int(20) NOT NULL AUTO_INCREMENT,
  `log_descripcion` mediumtext NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `proyecto_id` int(12) DEFAULT NULL,
  `log_fecha` int(10) DEFAULT NULL,
  PRIMARY KEY (`log_id`)
) ENGINE=InnoDB AUTO_INCREMENT=142 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `logs`
--

LOCK TABLES `logs` WRITE;
/*!40000 ALTER TABLE `logs` DISABLE KEYS */;
INSERT INTO `logs` (`log_id`, `log_descripcion`, `usuario_id`, `proyecto_id`, `log_fecha`) VALUES (1,'Se ingresó un nuevo proyecto llamado CÁMARAS LA PINTANA',1,13,1424435196),(2,'Se ingresó un nuevo proyecto llamado PROYECTO MASIVO SAN ANTONIO',1,14,1424716480),(3,'Se ingresó información adicional al proyecto ID: <a href=\"http://chilectra.s2.imacom.cl/app/index.php/proyecto/ingresar_info/14\">14</a>',1,NULL,1424716973),(4,'Se ingresó un nuevo proyecto llamado PRUEBA1',1,15,1428346711),(5,'Se eliminó el proyecto ID: 15',1,NULL,1428346864),(6,'Se ingresó un nuevo proyecto llamado PRUEBA1',1,16,1428346879),(7,'Se ingresó información adicional al proyecto ID: <a href=\"http://chilectra.s2.imacom.cl/app/index.php/proyecto/ingresar_info/16\">16</a>',1,NULL,1428346996),(8,'Se eliminó el proyecto ID: 16',1,NULL,1428347599),(9,'Se ingresó un nuevo proyecto llamado AAAA',1,17,1428348248),(10,'Se ingresó información adicional al proyecto ID: <a href=\"http://chilectra.s2.imacom.cl/app/index.php/proyecto/ingresar_info/17\">17</a>',1,NULL,1428348405),(11,'Se editó el proyecto ID: <a href=\"http://chilectra.s2.imacom.cl/app/index.php/proyecto/ingresar_info/17\">17</a>',1,17,1428348776),(12,'Se ingresó información adicional al proyecto ID: <a href=\"http://chilectra.s2.imacom.cl/app/index.php/proyecto/ingresar_info/17\">17</a>',1,NULL,1428348798),(13,'Se ingresó información adicional al proyecto ID: <a href=\"http://chilectra.s2.imacom.cl/app/index.php/proyecto/ingresar_info/17\">17</a>',1,NULL,1428348948),(14,'Se editó el proyecto ID: <a href=\"http://chilectra.s2.imacom.cl/app/index.php/proyecto/ingresar_info/17\">17</a>',1,17,1428350137),(15,'Se ingresó información adicional al proyecto ID: <a href=\"http://chilectra.s2.imacom.cl/app/index.php/proyecto/ingresar_info/17\">17</a>',1,NULL,1428350537),(16,'Se ingresó información adicional al proyecto ID: <a href=\"http://chilectra.s2.imacom.cl/app/index.php/proyecto/ingresar_info/13\">13</a>',1,NULL,1428411698),(17,'Se ingresó información adicional al proyecto ID: <a href=\"http://chilectra.s2.imacom.cl/app/index.php/proyecto/ingresar_info/13\">13</a>',1,NULL,1428411729),(18,'Se ingresó un nuevo proyecto llamado PROYECTO PRUEBA IMACOM',1,18,1429101850),(19,'Se ingresó información adicional al proyecto ID: <a href=\"http://chilectra.s2.imacom.cl/app/index.php/proyecto/ingresar_info/18\">18</a>',1,NULL,1429101916),(20,'Se editó el proyecto ID: <a href=\"http://chilectra.s2.imacom.cl/app/index.php/proyecto/ingresar_info/17\">17</a>',5,17,1429125830),(21,'Se editó el proyecto ID: <a href=\"http://chilectra.s2.imacom.cl/app/index.php/proyecto/ingresar_info/18\">18</a>',1,18,1429126116),(22,'Se ingresó información adicional al proyecto ID: <a href=\"http://chilectra.s2.imacom.cl/app/index.php/proyecto/ingresar_info/18\">18</a>',1,NULL,1429126151),(23,'Se ingresó un nuevo proyecto llamado CHILECTRA 1',4,19,1429126228),(24,'Se ingresó información adicional al proyecto ID: <a href=\"http://chilectra.s2.imacom.cl/app/index.php/proyecto/ingresar_info/19\">19</a>',4,NULL,1429126292),(25,'Se ingresó información adicional al proyecto ID: <a href=\"http://chilectra.s2.imacom.cl/app/index.php/proyecto/ingresar_info/19\">19</a>',5,NULL,1429126593),(26,'Se ingresó un nuevo proyecto llamado PRUEBA 1',1,20,1429127013),(27,'Se ingresó información adicional al proyecto ID: <a href=\"http://chilectra.s2.imacom.cl/app/index.php/proyecto/ingresar_info/20\">20</a>',1,NULL,1429127090),(28,'Se editó el proyecto ID: <a href=\"http://chilectra.s2.imacom.cl/app/index.php/proyecto/ingresar_info/20\">20</a>',1,20,1429127309),(29,'Se ingresó información adicional al proyecto ID: <a href=\"http://chilectra.s2.imacom.cl/app/index.php/proyecto/ingresar_info/20\">20</a>',5,NULL,1429129707),(30,'Se eliminó el proyecto ID: 12',1,NULL,1429285770),(31,'Se eliminó el proyecto ID: 13',1,NULL,1429285774),(32,'Se eliminó el proyecto ID: 14',1,NULL,1429285778),(33,'Se eliminó el proyecto ID: 17',1,NULL,1429285781),(34,'Se eliminó el proyecto ID: 18',1,NULL,1429285786),(35,'Se eliminó el proyecto ID: 19',1,NULL,1429285789),(36,'Se eliminó el proyecto ID: 20',1,NULL,1429285794),(37,'Se ingresó un nuevo proyecto llamado PROYECTO 1',4,21,1429532952),(38,'Se ingresó información adicional al proyecto ID: <a href=\"http://chilectra.s2.imacom.cl/app/index.php/proyecto/ingresar_info/21\">21</a>',4,NULL,1429533008),(39,'Se editó el proyecto ID: <a href=\"http://chilectra.s2.imacom.cl/app/index.php/proyecto/ingresar_info/21\">21</a>',4,21,1429533047),(40,'Se ingresó información adicional al proyecto ID: <a href=\"http://chilectra.s2.imacom.cl/app/index.php/proyecto/ingresar_info/21\">21</a>',4,NULL,1429533174),(41,'Se ingresó un nuevo proyecto llamado PROYECTO DE PRUEBA',1,22,1434118475),(42,'Se ingresó información adicional al proyecto ID: <a href=\"http://chilectra.s2.imacom.cl/app/index.php/proyecto/ingresar_info/22\">22</a>',1,NULL,1434118526),(43,'Se editó el proyecto ID: <a href=\"http://chilectra.s2.imacom.cl/app/index.php/proyecto/ingresar_info/22\">22</a>',1,22,1435689288),(44,'Se ingresó un nuevo proyecto llamado PROYECTO',1,23,1436359500),(45,'Se ingresó un nuevo proyecto llamado PROYECTO 001',1,24,1436449027),(46,'Se ingresó información adicional al proyecto ID: <a href=\"http://chilectra.s2.imacom.cl/app/index.php/proyecto/ingresar_info/24\">24</a>',1,NULL,1436449364),(47,'Se editó el proyecto ID: <a href=\"http://chilectra.s2.imacom.cl/app/index.php/proyecto/ingresar_info/24\">24</a>',1,24,1436467516),(48,'Se editó el proyecto ID: <a href=\"http://chilectra.s2.imacom.cl/app/index.php/proyecto/ingresar_info/24\">24</a>',1,24,1436977590),(49,'Se ingresó un nuevo proyecto llamado PROYECTO 002',1,25,1437153073),(50,'Se ingresó un nuevo proyecto llamado PROYECTO 002',1,26,1437153316),(51,'Se ingresó un nuevo proyecto llamado PROYECTO 002',1,27,1437153449),(52,'Se ingresó información adicional al proyecto ID: <a href=\"http://chilectra.s2.imacom.cl/app/index.php/proyecto/ingresar_info/27\">27</a>',1,NULL,1437153586),(53,'Se ingresó un nuevo proyecto llamado PROYECTO 003',1,28,1437154599),(54,'Se ingresó información adicional al proyecto ID: <a href=\"http://chilectra.s2.imacom.cl/app/index.php/proyecto/ingresar_info/28\">28</a>',1,NULL,1437154630),(55,'Se ingresó un nuevo proyecto llamado PROYECTO 004',1,29,1437154751),(56,'Se ingresó información adicional al proyecto ID: <a href=\"http://chilectra.s2.imacom.cl/app/index.php/proyecto/ingresar_info/29\">29</a>',1,NULL,1437154977),(57,'Se eliminó el proyecto ID: 28',1,NULL,1437155663),(58,'Se eliminó el proyecto ID: 27',1,NULL,1437156580),(59,'Se ingresó un nuevo proyecto llamado PROYECTO 002',1,30,1437157111),(60,'Se eliminó el proyecto ID: 30',1,NULL,1437157173),(61,'Se ingresó un nuevo proyecto llamado PROYECTO 005',1,31,1437157666),(62,'Se eliminó el proyecto ID: 31',1,NULL,1437157754),(63,'Se ingresó un nuevo proyecto llamado PROYECTO 005',1,32,1437157946),(64,'Se ingresó un nuevo proyecto llamado PROYECTO 006',1,33,1437410671),(65,'Se ingresó información adicional al proyecto ID: <a href=\"http://chilectra.s2.imacom.cl/app/index.php/proyecto/ingresar_info/33\">33</a>',1,NULL,1437411352),(66,'Se ingresó un nuevo proyecto llamado PROYECTO DE SUPER PRUEBA',1,34,1437655547),(67,'Se ingresó información adicional al proyecto ID: <a href=\"http://chilectra.s2.imacom.cl/app/index.php/proyecto/ingresar_info/34\">34</a>',1,NULL,1437656260),(68,'Se ingresó un nuevo proyecto llamado PROYECTO 007',1,35,1437666346),(69,'Se ingresó información adicional al proyecto ID: <a href=\"http://chilectra.s2.imacom.cl/app/index.php/proyecto/ingresar_info/35\">35</a>',1,NULL,1437666402),(70,'Se ingresó un nuevo proyecto llamado PROYECTO 008',1,36,1438048461),(71,'Se ingresó información adicional al proyecto ID: <a href=\"http://chilectra.s2.imacom.cl/app/index.php/proyecto/ingresar_info/36\">36</a>',1,NULL,1438048637),(72,'Se eliminó el proyecto ID: 36',1,NULL,1438051551),(73,'Se ingresó un nuevo proyecto llamado PROYECTO 008',1,37,1438051570),(74,'Se ingresó información adicional al proyecto ID: <a href=\"http://chilectra.s2.imacom.cl/app/index.php/proyecto/ingresar_info/37\">37</a>',1,NULL,1438051600),(75,'Se eliminó el proyecto ID: 37',1,NULL,1438052030),(76,'Se ingresó un nuevo proyecto llamado PROYECTO 008',1,38,1438052043),(77,'Se ingresó información adicional al proyecto ID: <a href=\"http://chilectra.s2.imacom.cl/app/index.php/proyecto/ingresar_info/38\">38</a>',1,NULL,1438052070),(78,'Se eliminó el proyecto ID: 38',4,NULL,1438052870),(79,'Se ingresó un nuevo proyecto llamado PROYECTO 008',4,39,1438052884),(80,'Se ingresó información adicional al proyecto ID: <a href=\"http://chilectra.s2.imacom.cl/app/index.php/proyecto/ingresar_info/39\">39</a>',4,NULL,1438052919),(81,'Se ingresó un nuevo proyecto llamado PROYECTO 009',4,40,1438053250),(82,'Se ingresó información adicional al proyecto ID: <a href=\"http://chilectra.s2.imacom.cl/app/index.php/proyecto/ingresar_info/40\">40</a>',4,NULL,1438053274),(83,'Se eliminó el proyecto ID: 32',1,NULL,1438196795),(84,'Se ingresó un nuevo proyecto llamado PROYECTO INFORMATICO ADUANAS CHILE',1,41,1438199703),(85,'Se ingresó información adicional al proyecto ID: <a href=\"http://chilectra.s2.imacom.cl/app/index.php/proyecto/ingresar_info/41\">41</a>',1,NULL,1438199776),(86,'Se ingresó un nuevo proyecto llamado IMACOM PRUEBA',1,42,1438261361),(87,'Se ingresó información adicional al proyecto ID: <a href=\"http://chilectra.s2.imacom.cl/app/index.php/proyecto/ingresar_info/42\">42</a>',1,NULL,1438261413),(88,'Se ingresó información adicional al proyecto ID: <a href=\"http://chilectra.s2.imacom.cl/app/index.php/proyecto/ingresar_info/42\">42</a>',1,NULL,1438261629),(89,'Se ingresó un nuevo proyecto llamado PROYECTO 101',4,43,1438270607),(90,'Se eliminó el proyecto ID: 43',4,NULL,1438272104),(91,'Se ingresó un nuevo proyecto llamado PROYECTO 101',4,44,1438272836),(92,'Se eliminó el proyecto ID: 44',4,NULL,1438273143),(93,'Se ingresó un nuevo proyecto llamado PROYECTO 101',4,45,1438273174),(94,'Se eliminó el proyecto ID: 45',4,NULL,1438273273),(95,'Se ingresó un nuevo proyecto llamado PROYECTO 101',4,46,1438273287),(96,'Se ingresó información adicional al proyecto ID: <a href=\"http://chilectra.s2.imacom.cl/app/index.php/proyecto/ingresar_info/46\">46</a>',4,NULL,1438274901),(97,'Se eliminó el proyecto ID: 46',4,NULL,1438275282),(98,'Se ingresó un nuevo proyecto llamado PROYECTO 101',1,47,1438275356),(99,'Se ingresó información adicional al proyecto ID: <a href=\"http://chilectra.s2.imacom.cl/app/index.php/proyecto/ingresar_info/47\">47</a>',4,NULL,1438281950),(100,'Se eliminó el proyecto ID: 47',1,NULL,1438284733),(101,'Se ingresó un nuevo proyecto llamado PROYECTO 101',1,48,1438284763),(102,'Se ingresó información adicional al proyecto ID: <a href=\"http://chilectra.s2.imacom.cl/app/index.php/proyecto/ingresar_info/48\">48</a>',1,NULL,1438284867),(103,'Se ingresó información adicional al proyecto ID: <a href=\"http://chilectra.s2.imacom.cl/app/index.php/proyecto/ingresar_info/48\">48</a>',1,NULL,1438285394),(104,'Se ingresó un nuevo proyecto llamado TESTING',1,49,1440766542),(105,'Se ingresó información adicional al proyecto ID: <a href=\"http://chilectra.s2.imacom.cl/app/index.php/proyecto/ingresar_info/49\">49</a>',1,NULL,1440766641),(106,'Se ingresó un nuevo proyecto llamado TESTING 02',1,50,1440884177),(107,'Se ingresó información adicional al proyecto ID: <a href=\"http://chilectra.s2.imacom.cl/app/index.php/proyecto/ingresar_info/50\">50</a>',1,NULL,1440884307),(108,'Se ingresó información adicional al proyecto ID: <a href=\"http://chilectra.s2.imacom.cl/app/index.php/proyecto/ingresar_info/50\">50</a>',4,NULL,1440885572),(109,'Se ingresó información adicional al proyecto ID: <a href=\"http://chilectra.s2.imacom.cl/app/index.php/proyecto/ingresar_info/50\">50</a>',1,NULL,1440885789),(110,'Se ingresó información adicional al proyecto ID: <a href=\"http://chilectra.s2.imacom.cl/app/index.php/proyecto/ingresar_info/49\">49</a>',5,NULL,1441024469),(111,'Se ingresó información adicional al proyecto ID: <a href=\"http://chilectra.s2.imacom.cl/app/index.php/proyecto/ingresar_info/50\">50</a>',1,NULL,1441032158),(112,'Se ingresó información adicional al proyecto ID: <a href=\"http://chilectra.s2.imacom.cl/app/index.php/proyecto/ingresar_info/50\">50</a>',1,NULL,1441032318),(113,'Se ingresó información adicional al proyecto ID: <a href=\"http://chilectra.s2.imacom.cl/app/index.php/proyecto/ingresar_info/50\">50</a>',1,NULL,1441033450),(114,'Se ingresó información adicional al proyecto ID: <a href=\"http://chilectra.s2.imacom.cl/app/index.php/proyecto/ingresar_info/50\">50</a>',1,NULL,1441033836),(115,'Se ingresó información adicional al proyecto ID: <a href=\"http://chilectra.s2.imacom.cl/app/index.php/proyecto/ingresar_info/50\">50</a>',1,NULL,1441034303),(116,'Se ingresó información adicional al proyecto ID: <a href=\"http://chilectra.s2.imacom.cl/app/index.php/proyecto/ingresar_info/50\">50</a>',1,NULL,1441034387),(117,'Se ingresó información adicional al proyecto ID: <a href=\"http://chilectra.s2.imacom.cl/app/index.php/proyecto/ingresar_info/50\">50</a>',1,NULL,1441034426),(118,'Se ingresó información adicional al proyecto ID: <a href=\"http://chilectra.s2.imacom.cl/app/index.php/proyecto/ingresar_info/50\">50</a>',1,NULL,1441034459),(119,'Se ingresó información adicional al proyecto ID: <a href=\"http://chilectra.s2.imacom.cl/app/index.php/proyecto/ingresar_info/50\">50</a>',1,NULL,1441034547),(120,'Se ingresó información adicional al proyecto ID: <a href=\"http://chilectra.s2.imacom.cl/app/index.php/proyecto/ingresar_info/50\">50</a>',1,NULL,1441034630),(121,'Se ingresó información adicional al proyecto ID: <a href=\"http://chilectra.s2.imacom.cl/app/index.php/proyecto/ingresar_info/50\">50</a>',1,NULL,1441034688),(122,'Se ingresó información adicional al proyecto ID: <a href=\"http://chilectra.s2.imacom.cl/app/index.php/proyecto/ingresar_info/50\">50</a>',1,NULL,1441035131),(123,'Se ingresó información adicional al proyecto ID: <a href=\"http://chilectra.s2.imacom.cl/app/index.php/proyecto/ingresar_info/50\">50</a>',1,NULL,1441035261),(124,'Se ingresó información adicional al proyecto ID: <a href=\"http://chilectra.s2.imacom.cl/app/index.php/proyecto/ingresar_info/50\">50</a>',1,NULL,1441035305),(125,'Se ingresó información adicional al proyecto ID: <a href=\"http://chilectra.s2.imacom.cl/app/index.php/proyecto/ingresar_info/50\">50</a>',1,NULL,1441035666),(126,'Se ingresó información adicional al proyecto ID: <a href=\"http://chilectra.s2.imacom.cl/app/index.php/proyecto/ingresar_info/50\">50</a>',1,NULL,1441036234),(127,'Se ingresó un nuevo proyecto llamado TESTING 03',1,51,1441056131),(128,'Se ingresó información adicional al proyecto ID: <a href=\"http://chilectra.s2.imacom.cl/app/index.php/proyecto/ingresar_info/51\">51</a>',1,NULL,1441056169),(129,'Se ingresó un nuevo proyecto llamado SUPER MEGA PROYECTO',1,52,1441200217),(130,'Se ingresó información adicional al proyecto ID: <a href=\"http://chilectra.s2.imacom.cl/app/index.php/proyecto/ingresar_info/52\">52</a>',1,NULL,1441201134),(131,'Se ingresó información adicional al proyecto ID: <a href=\"http://chilectra.s2.imacom.cl/app/index.php/proyecto/ingresar_info/52\">52</a>',1,NULL,1441201184),(132,'Se editó el proyecto ID: <a href=\"http://chilectra.s2.imacom.cl/app/index.php/proyecto/ingresar_info/52\">52</a>',1,52,1441201242),(133,'Se ingresó información adicional al proyecto ID: <a href=\"http://chilectra.s2.imacom.cl/app/index.php/proyecto/ingresar_info/52\">52</a>',1,NULL,1441201331),(134,'Se ingresó un nuevo proyecto llamado PRUEBA CHILECTRA',1,53,1441224104),(135,'Se ingresó información adicional al proyecto ID: <a href=\"http://chilectra.s2.imacom.cl/app/index.php/proyecto/ingresar_info/53\">53</a>',1,NULL,1441224129),(136,'Se eliminó el proyecto ID: 23',4,NULL,1441802281),(137,'Se ingresó un nuevo proyecto llamado TESTING 03',4,54,1441804593),(138,'Se eliminó el proyecto ID: 54',4,NULL,1441804632),(139,'Se ingresó un nuevo proyecto llamado Proyecto de prueba 01',1,54,1461673242),(140,'Se ingresó un nuevo proyecto llamado Proyecto de prueba 01',1,55,1461676866),(141,'Se ingresó información adicional al proyecto ID: <a href=\"http://chilectra.s2.imacom.cl/app/index.php/proyecto/ingresar_info/55\">55</a>',1,NULL,1461685224);
/*!40000 ALTER TABLE `logs` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`chilectra`@`localhost`*/ /*!50003 TRIGGER `chilectr_app`.`log_unix_time` BEFORE INSERT ON `chilectr_app`.`logs` FOR EACH ROW SET new.log_fecha = UNIX_TIMESTAMP(NOW()) */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `opciones`
--

DROP TABLE IF EXISTS `opciones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `opciones` (
  `opcion_id` int(12) NOT NULL AUTO_INCREMENT,
  `opcion_titulo` varchar(255) DEFAULT NULL,
  `opcion_valor` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`opcion_id`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `opciones`
--

LOCK TABLES `opciones` WRITE;
/*!40000 ALTER TABLE `opciones` DISABLE KEYS */;
INSERT INTO `opciones` (`opcion_id`, `opcion_titulo`, `opcion_valor`) VALUES (17,'LINEA_NEGOCIO','FULL ELECTRIC'),(18,'LINEA_NEGOCIO','GENERADORES'),(19,'LINEA_NEGOCIO','MASIVO AP'),(20,'LINEA_NEGOCIO','MMRR AP'),(21,'LINEA_NEGOCIO','PYS BT'),(22,'LINEA_NEGOCIO','PYS MT'),(23,'LINEA_NEGOCIO','SOLAR ELECTRIC'),(24,'LINEA_NEGOCIO','DUCTO DE BARRA'),(25,'LINEA_NEGOCIO','CÁMARAS DE VIGILANCIA'),(26,'LINEA_NEGOCIO','LED'),(27,'LINEA_NEGOCIO','FOTOVOLTAICO'),(28,'LINEA_NEGOCIO','N/A'),(29,'AREA_COMERCIAL','CCEE'),(30,'AREA_COMERCIAL','GGCC'),(31,'AREA_COMERCIAL','INM'),(32,'AREA_COMERCIAL','IYG'),(33,'AREA_COMERCIAL','N/A'),(34,'TIPO_PROYECTO','PI'),(35,'TIPO_PROYECTO','PA'),(36,'TIPO_PROYECTO','NV');
/*!40000 ALTER TABLE `opciones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `procesos`
--

DROP TABLE IF EXISTS `procesos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `procesos` (
  `proyecto_id` int(12) NOT NULL,
  `proceso_id` int(12) NOT NULL AUTO_INCREMENT,
  `etapa_id` int(12) NOT NULL,
  `etapa_v2_id` int(11) NOT NULL,
  `tarea_id` int(12) NOT NULL,
  `usuario_id` int(11) NOT NULL,
  `proceso_terminado` tinyint(1) NOT NULL DEFAULT '0',
  `proceso_fecha_inicio` varchar(12) DEFAULT NULL,
  `proceso_fecha_termino` varchar(12) DEFAULT NULL,
  PRIMARY KEY (`proceso_id`)
) ENGINE=InnoDB AUTO_INCREMENT=104 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `procesos`
--

LOCK TABLES `procesos` WRITE;
/*!40000 ALTER TABLE `procesos` DISABLE KEYS */;
INSERT INTO `procesos` (`proyecto_id`, `proceso_id`, `etapa_id`, `etapa_v2_id`, `tarea_id`, `usuario_id`, `proceso_terminado`, `proceso_fecha_inicio`, `proceso_fecha_termino`) VALUES (12,3,3,0,14,1,1,'1424438562','1424266476'),(12,5,3,0,15,4,1,'1424438562','1424266476'),(12,6,3,0,16,1,1,'1424265634','1424266476'),(12,7,3,0,17,1,1,'1424265785','1424265962'),(12,9,3,0,18,4,1,'1424265962','1424266246'),(12,10,5,0,19,4,1,'1424266246','1424266398'),(12,11,5,0,20,4,1,'1424266398','1424266417'),(12,12,6,0,21,1,1,'1424266417','1424266447'),(12,13,6,0,22,1,1,'1424266447','1424266457'),(12,14,6,0,23,1,1,'1424266457','1424266462'),(12,15,6,0,24,1,1,'1424266463','1424266469'),(12,16,6,0,25,1,1,'1424266469','1424266476'),(12,17,7,0,26,1,1,'1424266476','1424266504'),(12,18,7,0,27,1,1,'1424266504','1424266513'),(12,19,7,0,28,1,1,'1424266514','1424266522'),(12,20,7,0,29,1,1,'1424266522','1424266531'),(12,21,7,0,30,1,1,'1424266531','1424266536'),(12,22,7,0,31,1,1,'1424266536','1424266542'),(12,23,8,0,32,1,1,'1424266542','1424266552'),(12,24,8,0,33,1,1,'1424266552','1424266817'),(12,27,8,0,34,1,1,'1424266817','1424266821'),(12,28,9,0,35,1,1,'1424266821','1424266826'),(13,29,3,0,14,1,1,'1424435196','1428441811'),(14,30,3,0,14,1,0,'1424716480',NULL),(15,31,3,0,14,1,0,'1428346711',NULL),(16,32,3,0,14,1,0,'1428346879',NULL),(17,33,3,0,14,1,1,'1428348248','1428350519'),(17,34,3,0,15,4,0,'1428350519',NULL),(13,35,3,0,15,4,1,'1428441811','1429125879'),(18,36,3,0,14,1,1,'1429101850','1429102265'),(18,37,3,0,15,4,0,'1429102265',NULL),(13,38,3,0,16,1,0,'1429125879',NULL),(19,39,3,0,14,4,1,'1429126228','1429126315'),(19,40,3,0,15,4,1,'1429126315','1429126368'),(19,41,3,0,16,5,1,'1429126368','1429126792'),(19,42,3,0,17,3,0,'1429126792',NULL),(20,43,3,0,14,1,1,'1429127013','1429127333'),(20,44,3,0,15,4,1,'1429127333','1429127885'),(20,45,3,0,16,5,1,'1429127885','1429128025'),(20,46,3,0,17,5,1,'1429128025','1429128165'),(20,47,3,0,18,4,1,'1429128165','1429128351'),(20,48,5,0,19,4,0,'1429128351',NULL),(21,49,3,0,14,4,1,'1429532952','1429533191'),(21,50,3,0,15,4,1,'1429533191','1429533213'),(21,51,3,0,16,5,1,'1429533213','1429534448'),(21,52,3,0,17,5,1,'1429534448','1429562688'),(21,53,3,0,18,4,1,'1429562688','1429563488'),(21,54,5,0,19,4,1,'1429563488','1429564072'),(21,55,5,0,20,4,1,'1429564072','1429564899'),(21,56,6,0,21,5,1,'1429564899','1429565811'),(21,57,6,0,22,5,1,'1429565811','1429566635'),(21,58,6,0,23,5,1,'1429566635','1429648871'),(21,59,6,0,24,5,1,'1429648871','1429648878'),(21,60,6,0,25,5,1,'1429648878','1429649889'),(21,61,7,0,26,5,1,'1429649889','1429651010'),(21,62,7,0,27,5,1,'1429651010','1429652922'),(21,63,7,0,28,5,1,'1429652922','1429652989'),(21,64,7,0,29,5,1,'1429652989','1429652995'),(21,65,7,0,30,5,1,'1429652995','1429653010'),(21,66,7,0,31,5,1,'1429653010','1429653613'),(21,67,8,0,32,5,1,'1429653613','1429654624'),(21,68,8,0,33,5,1,'1429654624','1429654629'),(21,69,8,0,34,5,1,'1429654629','1429654633'),(21,70,9,0,35,5,1,'1429654633','1429654638'),(22,71,3,0,14,1,0,'1434118475',NULL),(23,72,3,0,14,1,0,'1436359500',NULL),(24,73,3,1,14,1,0,'1436449027',NULL),(27,74,0,1,0,1,0,'1437153449',NULL),(28,75,0,1,0,1,0,'1437154599',NULL),(29,76,0,1,0,1,0,'1437154751',NULL),(30,77,0,1,0,1,0,'1437157111',NULL),(31,78,0,1,0,1,0,'1437157666',NULL),(32,79,0,1,0,1,0,'1437157946',NULL),(33,80,0,1,0,1,0,'1437410671',NULL),(34,81,0,1,0,1,0,'1437655547',NULL),(35,82,0,1,0,1,0,'1437666346',NULL),(36,83,0,1,0,1,0,'1438048461',NULL),(37,84,0,1,0,1,0,'1438051570',NULL),(38,85,0,1,0,1,0,'1438052043',NULL),(39,86,0,1,0,4,0,'1438052884',NULL),(40,87,0,1,0,4,0,'1438053250',NULL),(41,88,0,1,0,1,0,'1438199703',NULL),(42,89,0,1,0,1,0,'1438261361',NULL),(43,90,0,1,0,4,0,'1438270607',NULL),(44,91,0,1,0,4,0,'1438272836',NULL),(45,92,0,1,0,4,0,'1438273174',NULL),(46,93,0,1,0,4,0,'1438273287',NULL),(47,94,0,1,0,1,0,'1438275356',NULL),(48,95,0,1,0,1,0,'1438284763',NULL),(49,96,0,1,0,1,0,'1440766542',NULL),(50,97,0,1,0,1,0,'1440884177',NULL),(51,98,0,1,0,1,0,'1441056131',NULL),(52,99,0,1,0,1,0,'1441200217',NULL),(53,100,0,1,0,1,0,'1441224104',NULL),(55,103,0,1,0,1,0,'1461676866',NULL);
/*!40000 ALTER TABLE `procesos` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`chilectra`@`localhost`*/ /*!50003 TRIGGER `chilectr_app`.`proceso_unix_time` BEFORE INSERT ON `chilectr_app`.`procesos` FOR EACH ROW SET new.proceso_fecha_inicio = UNIX_TIMESTAMP(NOW()) */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `procesos_v2`
--

DROP TABLE IF EXISTS `procesos_v2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `procesos_v2` (
  `proceso_v2_id` int(11) NOT NULL AUTO_INCREMENT,
  `proyecto_id` int(11) NOT NULL,
  `etapa_v2_id` int(11) NOT NULL,
  `fecha_de_inicio` varchar(12) DEFAULT NULL,
  `fecha_de_termino` varchar(12) DEFAULT NULL,
  PRIMARY KEY (`proceso_v2_id`)
) ENGINE=MyISAM AUTO_INCREMENT=98 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `procesos_v2`
--

LOCK TABLES `procesos_v2` WRITE;
/*!40000 ALTER TABLE `procesos_v2` DISABLE KEYS */;
INSERT INTO `procesos_v2` (`proceso_v2_id`, `proyecto_id`, `etapa_v2_id`, `fecha_de_inicio`, `fecha_de_termino`) VALUES (9,49,1,'1440766542','1440768918'),(89,35,1,'1437666346','1441143793'),(10,49,2,'1440768918','1440769122'),(11,49,3,'1440769122','1440772799'),(12,49,4,'1440772799','1440774326'),(13,49,5,'1440774326','1440774400'),(14,49,6,'1440774400','1440774455'),(15,49,7,'1440774455','1440774552'),(16,49,8,'1440774552','1440774792'),(17,49,9,'1440774792','1440774890'),(18,49,10,'1440774890','1440774955'),(19,49,11,'1440774955','1440774998'),(20,49,12,'1440774998','1440778017'),(21,49,13,'1440778017','1440778371'),(22,49,14,'1440778371','1440778815'),(23,21,2,'0','1440778907'),(24,42,4,'0','1440779518'),(25,21,3,'1440778907','1440780325'),(26,21,4,'1440780325','1440781318'),(27,21,5,'1440781318','1440786890'),(28,21,6,'1440786890','1440787034'),(29,21,7,'1440787034','1440787809'),(30,21,8,'1440787809','1440787963'),(31,21,9,'1440787963','1440788236'),(32,21,10,'1440788236','1440788273'),(33,21,11,'1440788273','1440788324'),(34,21,12,'1440788324','1440788522'),(35,21,13,'1440788522','1440788567'),(36,21,14,'1440788567','1440788630'),(37,21,15,'1440788630','1440789546'),(38,50,1,'1440884177','1440885730'),(39,50,2,'1440885730','1440885928'),(40,50,3,'1440885928','1440886014'),(41,50,4,'1440886014','1440886062'),(42,50,5,'1440886062','1440886112'),(43,50,6,'1440886112','1440887136'),(44,50,7,'1440887136','1440887161'),(45,50,7,'1440887136','1440887287'),(46,50,8,'1440887161','1440887524'),(47,50,9,'1440887524','1440887548'),(63,51,1,'1441056131','1441117507'),(49,49,15,'1440778815','1441024208'),(50,49,16,'1441024208','1441024806'),(51,49,17,'1441024806','1441025032'),(56,49,20,'1441027488','1441028138'),(54,49,18,'1441025032','1441027444'),(55,49,19,'1441025084','1441027488'),(57,49,20,'1441027488','1441028780'),(58,50,10,'1441008015','1441029371'),(59,50,11,'1441029371','1441029802'),(64,51,2,'1441117507','1441117564'),(65,51,3,'1441117564','1441117692'),(66,51,4,'1441117692','1441117769'),(67,51,5,'1441117769','1441117848'),(68,51,6,'1441117848','1441117910'),(69,51,7,'1441117910','1441118009'),(70,51,8,'1441118009','1441124849'),(71,51,9,'1441124849','1441124931'),(72,51,10,'1441124931','1441124982'),(73,51,11,'1441124982','1441125016'),(74,51,12,'1441125016','1441133083'),(75,51,13,'1441133083','1441133202'),(76,51,14,'1441133202','1441133305'),(77,50,12,'1441029802','1441137694'),(78,50,13,'1441137694','1441138000'),(79,50,14,'1441138000','1441138120'),(80,50,15,'1441138120','1441138273'),(81,51,15,'1441133305','1441140560'),(83,50,16,'1441138273','1441141697'),(84,50,17,'1441141697','1441142329'),(85,50,18,'1441142329','1441142358'),(86,50,19,'1441142358','1441142386'),(87,50,20,'1441142386','1441142394'),(93,55,1,'1461676866','1461699410'),(94,55,2,'1461699410','1461702220'),(95,55,3,'1461702220','1461703555'),(96,55,4,'1461703555','1461703917'),(97,55,5,'1461703917','1461704347');
/*!40000 ALTER TABLE `procesos_v2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `proyectos`
--

DROP TABLE IF EXISTS `proyectos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `proyectos` (
  `proyecto_id` int(12) NOT NULL AUTO_INCREMENT,
  `proyecto_nombre` varchar(300) DEFAULT NULL,
  `proyecto_tipo` varchar(60) DEFAULT NULL,
  `proyecto_cliente` varchar(255) DEFAULT NULL,
  `proyecto_linea` varchar(60) DEFAULT NULL,
  `proyecto_area` varchar(200) DEFAULT NULL,
  `proyecto_ft_real` date DEFAULT NULL,
  `proyecto_ft_proyectada` date DEFAULT NULL,
  `proyecto_ingreso_proyectado` int(14) DEFAULT NULL,
  `proyecto_ingreso_real` int(14) DEFAULT NULL,
  `proyecto_costo_proyectado` int(14) DEFAULT NULL,
  `proyecto_costo_real` int(14) DEFAULT NULL,
  `proyecto_margen_proyectado` int(14) DEFAULT NULL,
  `proyecto_margen_real` int(14) DEFAULT NULL,
  `proyecto_estado` varchar(60) DEFAULT NULL,
  `proyecto_garantia` int(4) DEFAULT NULL,
  `contratista_id` int(12) DEFAULT NULL,
  `proveedor_id` int(12) DEFAULT NULL,
  `ejecutivo_servicios_id` int(11) DEFAULT NULL,
  `ejecutivo_negocios_id` int(11) DEFAULT NULL,
  `proyecto_fecha_ingreso` varchar(10) DEFAULT NULL,
  `proyecto_terminado` tinyint(1) NOT NULL DEFAULT '0',
  `proyecto_etapa_actual` int(11) NOT NULL,
  PRIMARY KEY (`proyecto_id`)
) ENGINE=InnoDB AUTO_INCREMENT=56 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `proyectos`
--

LOCK TABLES `proyectos` WRITE;
/*!40000 ALTER TABLE `proyectos` DISABLE KEYS */;
INSERT INTO `proyectos` (`proyecto_id`, `proyecto_nombre`, `proyecto_tipo`, `proyecto_cliente`, `proyecto_linea`, `proyecto_area`, `proyecto_ft_real`, `proyecto_ft_proyectada`, `proyecto_ingreso_proyectado`, `proyecto_ingreso_real`, `proyecto_costo_proyectado`, `proyecto_costo_real`, `proyecto_margen_proyectado`, `proyecto_margen_real`, `proyecto_estado`, `proyecto_garantia`, `contratista_id`, `proveedor_id`, `ejecutivo_servicios_id`, `ejecutivo_negocios_id`, `proyecto_fecha_ingreso`, `proyecto_terminado`, `proyecto_etapa_actual`) VALUES (21,'PROYECTO 1','NV','HOTEL ATTON','SOLAR ELECTRIC','','2015-04-21','2015-04-30',0,0,0,0,NULL,NULL,NULL,NULL,NULL,NULL,1,4,'1429532952',0,16),(22,'PROYECTO DE PRUEBA','PI','JJCC','FULL ELECTRIC','0','0000-00-00','0000-00-00',0,0,0,0,NULL,NULL,NULL,NULL,NULL,NULL,3,4,'1434118475',0,1),(29,'PROYECTO 004','PI','CLIENTE 004','PYS BT','CCEE','2015-08-06','2015-07-21',0,0,0,0,NULL,NULL,NULL,NULL,NULL,NULL,1,4,'1437154751',1,6),(33,'PROYECTO 006','PA','CLIENTE 006','GENERADORES','CCEE','2015-09-03','2015-08-31',10000,8000,9000,7000,NULL,NULL,NULL,NULL,NULL,NULL,3,6,'1437410671',0,9),(34,'PROYECTO DE SUPER PRUEBA','PI','IMACOM','FULL ELECTRIC','CCEE','0000-00-00','0000-00-00',0,0,0,0,NULL,NULL,NULL,NULL,NULL,NULL,5,4,'1437655547',0,6),(35,'PROYECTO 007','PA','CLIENTE 007','GENERADORES','GGCC','2015-08-12','2015-10-29',123,123,123,123,NULL,NULL,NULL,NULL,NULL,NULL,1,4,'1437666346',0,2),(39,'PROYECTO 008','PA','CLIENTE 008','MMRR AP','GGCC','2015-07-31','2015-07-03',5000,2000,4000,1000,NULL,NULL,NULL,NULL,NULL,NULL,1,4,'1438052884',1,6),(40,'PROYECTO 009','PA','CLIENTE 009','GENERADORES','CCEE','2015-07-31','2015-07-03',5000,2000,4000,1000,NULL,NULL,NULL,NULL,NULL,NULL,1,4,'1438053250',0,3),(41,'PROYECTO INFORMATICO ADUANAS CHILE','PI','GOBIERNO DE CHILE','N/A','CCEE','0000-00-00','2015-08-31',1000000,0,5000050,0,NULL,NULL,NULL,NULL,NULL,NULL,5,4,'1438199703',0,1),(42,'IMACOM PRUEBA','PA','IMACOM INTERNO','LED','','2015-08-31','2015-08-31',40000000,40000000,20000000,20000000,NULL,NULL,NULL,NULL,NULL,NULL,1,4,'1438261361',0,5),(48,'PROYECTO 101','PI','CLIENTE 101','FULL ELECTRIC','','2015-07-30','2015-07-03',10000,0,10000,0,NULL,NULL,NULL,NULL,NULL,NULL,1,4,'1438284763',0,17),(49,'TESTING','NV','IMACOM TEST','LED','','2015-09-04','2015-09-04',0,0,0,0,NULL,NULL,NULL,NULL,NULL,NULL,5,4,'1440766542',1,21),(50,'TESTING 02','PI','IMACOM TEST','MASIVO AP','','2015-08-01','2015-09-30',100000,0,100000,0,NULL,NULL,NULL,NULL,NULL,NULL,1,4,'1440884177',1,21),(51,'TESTING 03','PA','CLIENTE TESTING 03','FULL ELECTRIC','CCEE','2015-09-30','2015-09-30',12345,12345,12345,12345,NULL,NULL,NULL,NULL,NULL,NULL,1,4,'1441056131',0,16),(52,'SUPER MEGA PROYECTO','PI','IMACOM','GENERADORES','CCEE','2015-09-30','2015-09-30',0,0,0,0,NULL,NULL,NULL,NULL,NULL,NULL,1,4,'1441200217',0,1),(53,'PRUEBA CHILECTRA','PI','IMACOM','GENERADORES','CCEE','0000-00-00','0000-00-00',0,0,0,0,NULL,NULL,NULL,NULL,NULL,NULL,1,4,'1441224104',0,1),(55,'Proyecto de prueba 01','PI','Cliente de prueba 01','FULL ELECTRIC','CCEE','2016-05-06','2016-05-06',500000,500000,400000,400000,NULL,NULL,NULL,NULL,NULL,NULL,1,4,'1461676866',0,6);
/*!40000 ALTER TABLE `proyectos` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`chilectra`@`localhost`*/ /*!50003 TRIGGER `chilectr_app`.`proyecto_unix_time` BEFORE INSERT ON `chilectr_app`.`proyectos` FOR EACH ROW SET new.proyecto_fecha_ingreso = UNIX_TIMESTAMP(NOW()) */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `proyectos_usuarios`
--

DROP TABLE IF EXISTS `proyectos_usuarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `proyectos_usuarios` (
  `proyecto_usuario_id` int(11) NOT NULL AUTO_INCREMENT,
  `proyecto_id` int(11) NOT NULL,
  `usuario_id` int(11) NOT NULL,
  PRIMARY KEY (`proyecto_usuario_id`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `proyectos_usuarios`
--

LOCK TABLES `proyectos_usuarios` WRITE;
/*!40000 ALTER TABLE `proyectos_usuarios` DISABLE KEYS */;
INSERT INTO `proyectos_usuarios` (`proyecto_usuario_id`, `proyecto_id`, `usuario_id`) VALUES (4,29,1),(6,21,1),(9,32,1),(10,33,1),(11,34,1),(12,35,1),(13,36,1),(14,37,1),(15,38,1),(16,39,4),(17,40,4),(18,41,1),(19,42,1),(20,43,4),(21,44,4),(22,45,4),(23,46,4),(24,47,1),(25,48,1),(26,49,1),(27,50,1),(28,51,1),(29,52,1),(30,53,1),(31,54,4),(33,55,1);
/*!40000 ALTER TABLE `proyectos_usuarios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sesiones`
--

DROP TABLE IF EXISTS `sesiones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sesiones` (
  `session_id` varchar(40) NOT NULL DEFAULT '0',
  `ip_address` varchar(45) NOT NULL DEFAULT '0',
  `user_agent` varchar(120) NOT NULL,
  `last_activity` int(10) unsigned NOT NULL DEFAULT '0',
  `user_data` text NOT NULL,
  PRIMARY KEY (`session_id`),
  KEY `last_activity_idx` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sesiones`
--

LOCK TABLES `sesiones` WRITE;
/*!40000 ALTER TABLE `sesiones` DISABLE KEYS */;
INSERT INTO `sesiones` (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('12f7bfb4fedf06884bbb50a29aa5f9e8','190.22.222.36','Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/49.0.2623.112 Safari/537.36',1461760156,''),('411950822dea64ee23847f2b291d01df','142.4.218.201','Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/40.0.2214.115 Safari/537.36',1464835079,''),('64aeda2d14a71ca85b413d58715d0205','179.8.132.207','Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.94 Safari/537.36',1462477895,''),('6cf85a33ccdd134aaf163f45539a6427','179.8.132.207','Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.94 Safari/537.36',1462477907,''),('90e4df0c6a08e9eece63369cfb78e4bd','186.79.45.248','Mozilla/5.0 (Windows NT 6.1; WOW64; rv:45.0) Gecko/20100101 Firefox/45.0',1461705161,'a:8:{s:9:\"user_data\";s:0:\"\";s:2:\"id\";s:1:\"4\";s:5:\"email\";s:16:\"nicole@imacom.cl\";s:7:\"permiso\";a:1:{i:0;s:5:\"admin\";}s:6:\"nombre\";s:6:\"NICOLE\";s:7:\"empresa\";s:0:\"\";s:16:\"apellido_paterno\";s:5:\"ERAZO\";s:4:\"auth\";b:1;}'),('9499e935484f1259aa9b19a490acaa5f','142.4.218.201','Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/40.0.2214.115 Safari/537.36',1461857384,''),('fac9d55f74cb24b3d1ff52aeb70445f9','190.22.200.168','Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.102 Safari/537.36',1465419487,'a:8:{s:9:\"user_data\";s:0:\"\";s:2:\"id\";s:1:\"1\";s:5:\"email\";s:17:\"soporte@imacom.cl\";s:7:\"permiso\";a:1:{i:0;s:5:\"admin\";}s:6:\"nombre\";s:8:\"Cristian\";s:7:\"empresa\";s:6:\"IMACOM\";s:16:\"apellido_paterno\";s:5:\"Yanez\";s:4:\"auth\";b:1;}');
/*!40000 ALTER TABLE `sesiones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tareas`
--

DROP TABLE IF EXISTS `tareas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tareas` (
  `tarea_id` int(12) NOT NULL AUTO_INCREMENT,
  `etapa_id` int(12) DEFAULT NULL,
  `tarea_nombre` varchar(120) DEFAULT NULL,
  `tarea_orden` int(2) NOT NULL,
  `tarea_rol` varchar(255) NOT NULL,
  PRIMARY KEY (`tarea_id`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tareas`
--

LOCK TABLES `tareas` WRITE;
/*!40000 ALTER TABLE `tareas` DISABLE KEYS */;
INSERT INTO `tareas` (`tarea_id`, `etapa_id`, `tarea_nombre`, `tarea_orden`, `tarea_rol`) VALUES (14,3,'INGRESO SOLICITUD AL SISTEMA',1,'EN'),(15,3,'ENVÍO SOLICITUD A CONTRATISTA',2,'EN'),(16,3,'DESARROLLO DE PROPUESTA',3,'ES'),(17,3,'REVISIÓN DE PROPUESTA',4,'ES'),(18,3,'ENVÍO PROPUESTA CLIENTE',5,'EN'),(19,5,'ETAPA DE NEGOCIACIÓN',1,'EN'),(20,5,'ADJUDICACIÓN',2,'EN'),(21,6,'ENTREGA DE TERRENO',1,'ES'),(22,6,'ADQUISICIÓN DE EQUIPOS Y PRODUCTOS',2,'ES'),(23,6,'INGENIERÍA DE DETALLE',3,'ES'),(24,6,'OBRAS CIVILES U OTRAS',4,'ES'),(25,6,'INSTALACIÓN DE EQUIPOS',5,'ES'),(26,7,'PUESTA EN MARCHA DEL SISTEMA',1,'ES'),(27,7,'CORRECCIÓN DE OBSERVACIONES',2,'ES'),(28,7,'RECEPCIÓN PROVISORIA',3,'ES'),(29,7,'INICIO DE LA ETAPA DE GARANTÍA',4,'ES'),(30,7,'CAPACITACIÓN',5,'ES'),(31,7,'ENTREGA DE MANUALES E INFORMACIÓN DE POSTVENTA Y GARANTÍA',6,'ES'),(32,8,'ATENCIÓN DE POSTVENTA',1,'ES'),(33,8,'PROCESO DE GARANTÍA',2,'ES'),(34,8,'INFORMAR PLAZOS DE GARANTÍA Y POSTVENTA',3,'ES'),(35,9,'RECEPCIÓN DEFINITIVA',1,'ES');
/*!40000 ALTER TABLE `tareas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuarios`
--

DROP TABLE IF EXISTS `usuarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usuarios` (
  `usuario_id` int(11) NOT NULL AUTO_INCREMENT,
  `nombres` varchar(45) DEFAULT NULL,
  `apellido_paterno` varchar(60) DEFAULT NULL,
  `apellido_materno` varchar(30) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `clave` varchar(123) DEFAULT NULL,
  `rut` varchar(100) DEFAULT NULL,
  `comuna_id` int(11) DEFAULT NULL,
  `region_id` int(11) DEFAULT NULL,
  `direccion` varchar(255) DEFAULT NULL,
  `telefono` varchar(100) DEFAULT NULL,
  `celular` varchar(100) DEFAULT NULL,
  `activo` tinyint(1) DEFAULT '1',
  `activo_admin` int(1) DEFAULT NULL,
  `fecha_nacimiento` date DEFAULT NULL,
  `fecha_creacion` timestamp NULL DEFAULT NULL,
  `enviar_mail` tinyint(1) DEFAULT NULL,
  `token_activacion` varchar(40) DEFAULT NULL,
  `token_recuperar_clave` varchar(40) DEFAULT NULL,
  `permiso` text NOT NULL,
  `empresa` varchar(255) DEFAULT NULL,
  `cliente` tinyint(1) NOT NULL DEFAULT '0',
  `pais` varchar(255) DEFAULT NULL,
  `creacion` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `nacionalidad` varchar(255) DEFAULT NULL,
  `rol` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`usuario_id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuarios`
--

LOCK TABLES `usuarios` WRITE;
/*!40000 ALTER TABLE `usuarios` DISABLE KEYS */;
INSERT INTO `usuarios` (`usuario_id`, `nombres`, `apellido_paterno`, `apellido_materno`, `email`, `clave`, `rut`, `comuna_id`, `region_id`, `direccion`, `telefono`, `celular`, `activo`, `activo_admin`, `fecha_nacimiento`, `fecha_creacion`, `enviar_mail`, `token_activacion`, `token_recuperar_clave`, `permiso`, `empresa`, `cliente`, `pais`, `creacion`, `nacionalidad`, `rol`) VALUES (1,'Cristian','Yanez','Lagos','soporte@imacom.cl','$1$hPGBMSfK$9jRg2jMBCKMy9gj4slspR.','0',NULL,NULL,NULL,'56123467','',1,1,NULL,NULL,NULL,NULL,'9544664d15b8f3c6f90f174dffd6413734f29d11','a:1:{i:0;s:5:\"admin\";}','IMACOM',0,'0','0000-00-00 00:00:00','0','ES'),(2,'JUAN','REYES','COLLAO','jr@chilectra.cl','$1$gEqUdPqI$Jfk3VlTIZUB6NodAhOMT/1','0',NULL,NULL,NULL,'','+56994691238',1,1,NULL,NULL,0,NULL,NULL,'a:1:{i:0;s:7:\"usuario\";}',NULL,0,'0','2015-02-10 13:26:35','0',NULL),(3,'OSCAR','JIMENEZ','A','oja@chilectra.cl','$1$K7z3kWyq$xLn3F30FNVt9QHcxcFqmh/','0',NULL,NULL,NULL,'26752694','+56991908635',1,1,NULL,NULL,0,NULL,NULL,'a:1:{i:0;s:7:\"usuario\";}','',0,'0','2015-02-10 15:29:05','0','ES'),(4,'NICOLE','ERAZO','','nicole@imacom.cl','$1$hPGBMSfK$9jRg2jMBCKMy9gj4slspR.','0',NULL,NULL,NULL,'','',1,1,NULL,NULL,0,NULL,'e0ab584d16c204137c29e57af986544935db4e8f','a:1:{i:0;s:5:\"admin\";}','',0,'0','2015-02-11 15:46:08','0','EN'),(5,'IVAN','HERMOSILLA','','ivan@imacom.cl','$1$hPGBMSfK$9jRg2jMBCKMy9gj4slspR.','0',NULL,NULL,NULL,'22222222','',1,1,NULL,NULL,0,NULL,NULL,'a:1:{i:0;s:7:\"usuario\";}','',0,'0','2015-02-17 12:39:50','0','ES'),(6,'MARCELO','ALBORNOZ','SOTO','mas@chilectra.cl','$1$MqNd191b$azJcMuDtPnX.CS4DZYK49/','0',NULL,NULL,NULL,'226752960','+56991908599',0,1,NULL,NULL,0,NULL,NULL,'a:1:{i:0;s:7:\"usuario\";}',NULL,0,'0','2015-02-20 12:28:41','0','EN'),(7,'FELIPE','DONOSO','','fadv@chilectra.cl','$1$Mws6SBPc$cdpNnPLOada90pnTYqZUf1','0',NULL,NULL,NULL,'','',0,1,NULL,NULL,0,NULL,NULL,'a:1:{i:0;s:5:\"admin\";}',NULL,0,'0','2015-04-17 15:56:11','0','NA'),(10,'GIAN FRANCO','PATRONE','','gfpg@chilectra.cl','$1$SVDDJ7Nk$gKurCiDNAIjw8fG06E3Qg1','0',NULL,NULL,NULL,'','',0,1,NULL,NULL,0,NULL,NULL,'a:1:{i:0;s:7:\"usuario\";}',NULL,0,'0','2015-04-20 12:23:27','0','ES'),(11,'HENRY','NOVA','MERCADO','hlnm@chilectra.cl','$1$BC3Rx.Bm$c.vtzsRR96Vj6EMUegGgu1','0',NULL,NULL,NULL,'','',0,1,NULL,NULL,0,NULL,NULL,'a:1:{i:0;s:7:\"usuario\";}',NULL,0,'0','2015-04-20 12:24:13','0','EN'),(12,'CONTRATISTA','CONTRATISTA','CONTRATISTA','esteban.imacom@gmail.com','$1$hPGBMSfK$9jRg2jMBCKMy9gj4slspR.','0',NULL,NULL,NULL,'876876786','67567567',0,1,NULL,NULL,0,NULL,'e5326b892593699d349438e5bc971dc7dcdd9f86','a:1:{i:0;s:7:\"usuario\";}',NULL,0,'0','2015-07-30 13:22:16','0','NA');
/*!40000 ALTER TABLE `usuarios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'chilectr_app'
--

--
-- Dumping routines for database 'chilectr_app'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-06-23 14:48:05
